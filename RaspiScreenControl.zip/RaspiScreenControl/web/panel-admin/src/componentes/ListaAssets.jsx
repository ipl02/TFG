//Componente para mostrar la lista de assets
import React, { useEffect, useState } from 'react';   // Importa React, useEffect y useState para manejar el estado y el ciclo de vida del componente
import axios from 'axios'; // Importa axios para hacer peticiones HTTP
import './ListaAssets.css';

// Definir la URL base de la API
const API_URL = 'http://localhost:3000/api';

// Configuración base de Axios
axios.defaults.baseURL = 'http://localhost:3000';
axios.defaults.headers.common['Content-Type'] = 'application/json';

// Interceptor para añadir el token a todas las solicitudes
axios.interceptors.request.use(
  config => {
    const token = localStorage.getItem('token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  error => Promise.reject(error)
);

// Función para comprimir una imagen
const compressImage = (file) => {
  return new Promise((resolve, reject) => {
    if (!file.type.startsWith('image/')) {
      // Si no es una imagen, devolver el archivo original
      resolve(file);
      return;
    }

    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = (event) => {
      const img = new Image();
      img.src = event.target.result;
      img.onload = () => {
        const canvas = document.createElement('canvas');
        let width = img.width;
        let height = img.height;

        // Calcular nuevas dimensiones manteniendo la proporción
        const MAX_WIDTH = 1920;
        const MAX_HEIGHT = 1080;
        if (width > height) {
          if (width > MAX_WIDTH) {
            height = Math.round((height * MAX_WIDTH) / width);
            width = MAX_WIDTH;
          }
        } else {
          if (height > MAX_HEIGHT) {
            width = Math.round((width * MAX_HEIGHT) / height);
            height = MAX_HEIGHT;
          }
        }

        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        ctx.drawImage(img, 0, 0, width, height);

        // Convertir a blob con calidad reducida
        canvas.toBlob(
          (blob) => {
            // Crear un nuevo archivo con el blob comprimido
            const compressedFile = new File([blob], file.name, {
              type: 'image/jpeg',
              lastModified: Date.now(),
            });
            resolve(compressedFile);
          },
          'image/jpeg',
          0.7 // Calidad de compresión (0.7 = 70%)
        );
      };
      img.onerror = reject;
    };
    reader.onerror = reject;
  });
};

//Componente para mostrar la lista de assets
const ListaAssets = () => {
  //Estado para almacenar los assets      
  const [assets, setAssets] = useState([]);
  const [error, setError] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [editandoAsset, setEditandoAsset] = useState(null);
  const [showEditModal, setShowEditModal] = useState(false);
  const [showAddModal, setShowAddModal] = useState(false);
  const [filtroTipo, setFiltroTipo] = useState('todos'); // 'todos', 'imagen', 'video'
  const [inputMode, setInputMode] = useState('file'); // 'file' o 'url'
  
  // Estados para el formulario de nuevo asset
  const [nuevoAsset, setNuevoAsset] = useState({
    name: '',
    file: null,
    uri: '', // Siempre inicializado como string vacío
    mimetype: '',
    duration: 60,
    start_date: new Date().toISOString().slice(0, 19).replace('T', ' '),
    end_date: new Date(new Date().getFullYear() + 1, 5, 13).toISOString().slice(0, 19).replace('T', ' '),
    is_active: 1,
    is_enabled: 1,
    is_processing: 0,
    nocache: 0,
    skip_asset_check: 0,
    play_order: 0,
    usuario_id: 2
  });
  const [previewUrl, setPreviewUrl] = useState(null);
  const [isUploading, setIsUploading] = useState(false);

  // Efecto para controlar el scroll del body cuando cualquier modal está abierto
  useEffect(() => {
    if (showAddModal || showEditModal) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'unset';
    }
    // Limpiar el efecto al desmontar el componente o al cerrar el modal
    return () => {
      document.body.style.overflow = 'unset';
    };
  }, [showAddModal, showEditModal]); // Dependencia de ambos estados de modal

  // Cargar assets
  const cargarAssets = async () => {
    setError(null);
    setIsLoading(true);
    try {
      const response = await axios.get(`${API_URL}/assets`);
      console.log('Assets cargados:', response.data);
      setAssets(response.data);
    } catch (error) {
      console.error('Error al cargar assets:', error);
      setError('Error al cargar los assets. Por favor, inténtalo de nuevo.');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    cargarAssets();
  }, []);

  // Eliminar asset
  const eliminarAsset = async (id) => {
    if (!window.confirm('¿Estás seguro de que quieres eliminar este asset?')) {
      return;
    }

    setError(null);
    try {
      const response = await axios.delete(`${API_URL}/assets/${id}`);
      console.log('Asset eliminado:', response.data);
      await cargarAssets();
    } catch (error) {
      console.error('Error al eliminar asset:', error);
      
      if (error.response?.status === 400 && error.response?.data?.programaciones) {
        setError(`Este asset está siendo usado en ${error.response.data.programaciones} programaciones. Por favor, elimina primero las programaciones asociadas.`);
        return;
      }
      
      setError(error.response?.data?.error || 'Error al eliminar el asset. Por favor, inténtalo de nuevo.');
    }
  };

  // Filtrar assets según el tipo seleccionado
  const assetsFiltrados = assets.filter(asset => {
    if (filtroTipo === 'todos') return true;
    if (filtroTipo === 'imagen') return asset.mimetype?.startsWith('image/');
    if (filtroTipo === 'video') return asset.mimetype?.startsWith('video/');
    return true;
  });

  // Función para formatear la fecha
  const formatDate = (dateString) => {
    if (!dateString) return 'N/A';
    try {
      const date = new Date(dateString);
      if (isNaN(date.getTime())) {
        console.error('Fecha inválida:', dateString);
        return 'Fecha inválida';
      }
      return date.toLocaleString('es-ES', {
        year: 'numeric',
        month: '2-digit',
        day: '2-digit',
        hour: '2-digit',
        minute: '2-digit',
        hour12: false
      });
    } catch (err) {
      console.error('Error al formatear fecha:', err);
      return 'Error en fecha';
    }
  };

  // Función para obtener el tipo de asset de forma legible
  const getTipoAsset = (mimetype) => {
    if (!mimetype) return 'Desconocido';
    if (mimetype.startsWith('image/')) return 'Imagen';
    if (mimetype.startsWith('video/')) return 'Video';
    return mimetype;
  };

  // Función para manejar el cambio de archivo
  const handleFileChange = async (e) => {
    const file = e.target.files[0];
    if (!file) {
      setNuevoAsset(prev => ({ ...prev, file: null, uri: '', mimetype: '' }));
      setPreviewUrl(null);
      return;
    }

    if (!file.type.startsWith('image/') && !file.type.startsWith('video/')) {
      setError('Por favor, selecciona un archivo de imagen o video válido.');
      e.target.value = '';
      setNuevoAsset(prev => ({ ...prev, file: null, uri: '', mimetype: '' }));
      setPreviewUrl(null);
      return;
    }

    if (file.size > 50 * 1024 * 1024) {
      setError('El archivo es demasiado grande. El tamaño máximo permitido es 50MB.');
      e.target.value = '';
      setNuevoAsset(prev => ({ ...prev, file: null, uri: '', mimetype: '' }));
      setPreviewUrl(null);
      return;
    }

    try {
      const processedFile = await compressImage(file);
      setNuevoAsset(prev => ({
        ...prev,
        file: processedFile,
        uri: '', // Aseguramos que uri esté vacío en modo archivo
        mimetype: processedFile.type
      }));
      const url = URL.createObjectURL(processedFile);
      setPreviewUrl(url);
    } catch (error) {
      console.error('Error al procesar el archivo:', error);
      setError('Error al procesar el archivo. Por favor, inténtalo de nuevo.');
      e.target.value = '';
      setNuevoAsset(prev => ({ ...prev, file: null, uri: '', mimetype: '' }));
      setPreviewUrl(null);
    }
  };

  // Función para limpiar el formulario de agregar/editar
  const limpiarFormulario = () => {
    setNuevoAsset({
      name: '',
      file: null,
      uri: '', // Siempre inicializado como string vacío
      mimetype: '',
      duration: 60,
      start_date: new Date().toISOString().slice(0, 19).replace('T', ' '),
      end_date: new Date(new Date().getFullYear() + 1, 5, 13).toISOString().slice(0, 19).replace('T', ' '),
      is_active: 1,
      is_enabled: 1,
      is_processing: 0,
      nocache: 0,
      skip_asset_check: 0,
      play_order: 0,
      usuario_id: 2
    });
    setPreviewUrl(null);
    setEditandoAsset(null);
    setInputMode('file');
    setError(null);
  };

  // Función para cargar un asset para editar
  const cargarAssetParaEditar = (asset) => {
    console.log('cargarAssetParaEditar: Iniciando edición del asset:', asset);
    setEditandoAsset(asset);

    // Determinar el inputMode basado en la URI
    const isDataUrl = asset.uri && asset.uri.startsWith('data:');
    setInputMode(isDataUrl ? 'file' : 'url');

    setNuevoAsset({
      name: asset.name || '',
      file: null,
      uri: isDataUrl ? '' : (asset.uri || ''), // Aseguramos que uri siempre sea string
      mimetype: asset.mimetype || '',
      duration: asset.duration || 60,
      start_date: asset.start_date || new Date().toISOString().slice(0, 19).replace('T', ' '),
      end_date: asset.end_date || new Date(new Date().getFullYear() + 1, 5, 13).toISOString().slice(0, 19).replace('T', ' '),
      is_active: asset.is_active ?? 1,
      is_enabled: asset.is_enabled ?? 1,
      is_processing: asset.is_processing ?? 0,
      nocache: asset.nocache ?? 0,
      skip_asset_check: asset.skip_asset_check ?? 0,
      play_order: asset.play_order ?? 0,
      usuario_id: asset.usuario_id || 2
    });
    setPreviewUrl(isDataUrl ? asset.uri : null);
    setShowEditModal(true); // Abrir el modal de edición
    console.log('cargarAssetParaEditar: Modal de edición abierto y datos cargados');
  };

  // Función para validar los datos antes de enviar
  const validarDatos = () => {
    console.log('validarDatos: Iniciando validación...'); // Log de inicio de validación
    const errores = [];

    if (!nuevoAsset.name) {
      errores.push('El nombre del asset es requerido');
    }

    if (inputMode === 'file') {
      if (!nuevoAsset.file && !editandoAsset) {
        errores.push('Debe seleccionar un archivo');
      }
      if (!nuevoAsset.mimetype) {
        errores.push('El tipo de archivo es requerido');
      }
    } else if (inputMode === 'url') {
      if (!nuevoAsset.uri) {
        errores.push('La URL es requerida');
      }
      if (!nuevoAsset.mimetype) {
        errores.push('El tipo de archivo es requerido');
      }
    }
    console.log('validarDatos: Errores encontrados:', errores); // Log de errores
    console.log('validarDatos: Resultado de la validación (true si es válido):', errores.length === 0);
    return errores.length === 0;
  };

  // Función para manejar el envío del formulario de edición
  const handleUpdate = async (e) => {
    e.preventDefault();
    console.log('handleUpdate: Iniciando actualización...'); // Log de inicio
    console.log('handleUpdate: Estado actual de nuevoAsset:', nuevoAsset);
    console.log('handleUpdate: Estado actual de editandoAsset:', editandoAsset);

    setError(null);
    setIsUploading(true);
    console.log('handleUpdate: isUploading establecido en true.'); // Log de cambio de estado

    const isValid = validarDatos(); // Captura el resultado de la validación
    console.log('handleUpdate: Resultado de validarDatos():', isValid); // Log del resultado de validación

    if (!isValid) {
      setIsUploading(false);
      console.log('handleUpdate: Validación fallida, cancelando actualización.'); // Log de validación fallida
      return;
    }

    try {
      let uriToUpdate = nuevoAsset.uri;
      let mimetypeToUpdate = nuevoAsset.mimetype;

      if (inputMode === 'file') {
        if (nuevoAsset.file) {
          console.log('handleUpdate: Procesando nuevo archivo...'); // Log de procesamiento de archivo
          const reader = new FileReader();
          await new Promise((resolve, reject) => {
            reader.readAsDataURL(nuevoAsset.file);
            reader.onload = () => {
              uriToUpdate = `data:${nuevoAsset.mimetype};base64,${reader.result.split(',')[1]}`;
              mimetypeToUpdate = nuevoAsset.mimetype;
              console.log('handleUpdate: Archivo procesado y convertido a base64'); // Log de éxito
              resolve();
            };
            reader.onerror = (error) => {
              console.error('handleUpdate: Error al procesar archivo:', error); // Log de error
              reject(error);
            };
          });
        } else if (editandoAsset.uri && editandoAsset.uri.startsWith('data:')) {
          console.log('handleUpdate: Manteniendo URI existente en base64'); // Log de mantenimiento de URI
          uriToUpdate = editandoAsset.uri;
          mimetypeToUpdate = editandoAsset.mimetype;
        } else {
          setError('Debe seleccionar un archivo o proporcionar una URL válida');
          console.log('handleUpdate: Error - No se proporcionó archivo ni URL válida'); // Log de error
          return;
        }
      }

      const assetData = {
        name: nuevoAsset.name,
        uri: uriToUpdate,
        mimetype: mimetypeToUpdate,
        duration: nuevoAsset.duration,
        start_date: nuevoAsset.start_date,
        end_date: nuevoAsset.end_date,
        is_active: nuevoAsset.is_active,
        is_enabled: nuevoAsset.is_enabled,
        is_processing: nuevoAsset.is_processing,
        nocache: nuevoAsset.nocache,
        skip_asset_check: nuevoAsset.skip_asset_check,
        play_order: nuevoAsset.play_order,
        usuario_id: nuevoAsset.usuario_id,
      };

      console.log('handleUpdate: Enviando datos al servidor:', {
        ...assetData,
        uri: assetData.uri ? `${assetData.uri.substring(0, 50)}...` : null // Truncar URI para el log
      });

      const response = await axios.put(`${API_URL}/assets/${editandoAsset.id}`, assetData);
      console.log('handleUpdate: Respuesta del servidor:', response.data); // Log de respuesta exitosa
      
      setShowEditModal(false);
      limpiarFormulario();
      await cargarAssets();
      console.log('handleUpdate: Asset actualizado y lista recargada'); // Log de éxito final

    } catch (error) {
      console.error('handleUpdate: Error al actualizar asset:', error); // Log de error
      setError(error.response?.data?.error || 'Error al actualizar el asset. Por favor, inténtalo de nuevo.');
    } finally {
      setIsUploading(false);
      console.log('handleUpdate: Proceso de actualización finalizado'); // Log de finalización
    }
  };

  // Función para manejar el envío del formulario de agregar
  const handleSubmit = async (e) => {
    e.preventDefault();
    console.log('handleSubmit: Iniciando...'); // Log de inicio
    console.log('handleSubmit: Estado actual de nuevoAsset:', nuevoAsset);

    setError(null);
    setIsUploading(true);
    console.log('handleSubmit: isUploading establecido en true.'); // Log de cambio de estado

    const isValid = validarDatos(); // Captura el resultado de la validación
    console.log('handleSubmit: Resultado de validarDatos():', isValid); // Log del resultado de validación

    if (!isValid) {
      setIsUploading(false);
      console.log('handleSubmit: isUploading establecido en false debido a validación fallida.'); // Log de cambio de estado
      return;
    }

    try {
      console.log('handleSubmit: Iniciando bloque try para envío.'); // Log de inicio de try
      let uriToSend = nuevoAsset.uri;
      let mimetypeToSend = nuevoAsset.mimetype;

      if (inputMode === 'file') {
        console.log('handleSubmit: Modo de entrada es archivo.'); // Log de modo archivo
        if (!nuevoAsset.file) {
          throw new Error('Archivo no encontrado para subir.');
        }
        const reader = new FileReader();
        console.log('handleSubmit: FileReader creado. Leyendo archivo...'); // Log de lectura de archivo
        await new Promise((resolve, reject) => {
          reader.readAsDataURL(nuevoAsset.file);
          reader.onload = () => {
            console.log('handleSubmit: Archivo leído con éxito.'); // Log de archivo leído
            uriToSend = `data:${nuevoAsset.mimetype};base64,${reader.result.split(',')[1]}`;
            resolve();
          };
          reader.onerror = (error) => {
            console.error('handleSubmit: Error al leer el archivo:', error); // Log de error de lectura
            reject(error);
          };
        });
      }
          
      const assetData = {
        name: nuevoAsset.name,
        uri: uriToSend,
        mimetype: mimetypeToSend,
        duration: nuevoAsset.duration,
        start_date: nuevoAsset.start_date,
        end_date: nuevoAsset.end_date,
        is_active: nuevoAsset.is_active,
        is_enabled: nuevoAsset.is_enabled,
        is_processing: nuevoAsset.is_processing,
        nocache: nuevoAsset.nocache,
        skip_asset_check: nuevoAsset.skip_asset_check,
        play_order: nuevoAsset.play_order,
        usuario_id: nuevoAsset.usuario_id
      };
      console.log('handleSubmit: Datos del asset a enviar:', assetData); // Log de datos a enviar

      const response = await axios.post(`${API_URL}/assets`, assetData);
      console.log('handleSubmit: Petición POST completada.'); // Nuevo log
      console.log('handleSubmit: Respuesta exitosa de la API:', response.data); // Log de respuesta exitosa
      setShowAddModal(false);
      limpiarFormulario();
      await cargarAssets();
    } catch (error) {
      console.error('handleSubmit: Error general en try block:', error); // Log de error general
      setError(error.response?.data?.error || 'Error al subir el asset. Por favor, inténtalo de nuevo.');
    } finally {
      setIsUploading(false);
      console.log('handleSubmit: isUploading establecido en false en finally.'); // Log de cambio de estado
    }
  };

  //Renderiza el componente
  return (
    <div className="lista-assets">
      <div className="assets-header">
        <h2>Gestión de Assets</h2>
        <div className="assets-controls">
          <select 
            value={filtroTipo} 
            onChange={(e) => setFiltroTipo(e.target.value)}
            className="filtro-tipo"
          >
            <option value="todos">Todos los tipos</option>
            <option value="imagen">Solo imágenes</option>
            <option value="video">Solo videos</option>
          </select>
          <button 
            onClick={() => { setShowAddModal(true); limpiarFormulario(); }}
            className="btn-agregar"
          >
            Agregar Asset
          </button>
        </div>
      </div>

      {error && (
        <div className="error-message">
          {error}
        </div>
      )}

      {isLoading ? (
        <div className="loading-message">Cargando assets...</div>
      ) : (
        <div className="assets-list">
          {assetsFiltrados.length > 0 ? (
            <table>
              <thead>
                <tr>
                  <th>ID</th>
                  <th>Nombre</th>
                  <th>Tipo</th>
                  <th>Duración</th>
                  <th>Fecha Inicio</th>
                  <th>Fecha Fin</th>
                  <th>Estado</th>
                  <th>Acciones</th>
                </tr>
              </thead>
              <tbody>
                {assetsFiltrados.map(asset => (
                  <tr key={asset.id}>
                    <td>{asset.id}</td>
                    <td>{asset.name}</td>
                    <td>{getTipoAsset(asset.mimetype)}</td>
                    <td>{asset.duration || 'N/A'}</td>
                    <td>{formatDate(asset.start_date)}</td>
                    <td>{formatDate(asset.end_date)}</td>
                    <td>
                      <span className={`estado-badge ${asset.is_active ? 'activo' : 'inactivo'}`}>
                        {asset.is_active ? 'Activo' : 'Inactivo'}
                      </span>
                    </td>
                    <td>
                      <button 
                        onClick={() => cargarAssetParaEditar(asset)}
                        className="btn-editar"
                        disabled={isUploading}
                      >
                        Editar
                      </button>
                      <button 
                        onClick={() => eliminarAsset(asset.id)}
                        className="btn-eliminar"
                        disabled={isUploading}
                      >
                        Eliminar
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          ) : (
            <p>No hay assets disponibles</p>
          )}
        </div>
      )}

      {/* Modal para agregar asset */}
      {showAddModal && (
        <div className="modal">
          <div className="modal-content">
            <h2>Agregar Nuevo Asset</h2>
            <form onSubmit={handleSubmit} className="asset-form">
              <div className="form-group">
                <label>Nombre del asset *</label>
                <input
                  type="text"
                  value={nuevoAsset.name}
                  onChange={e => setNuevoAsset(prev => ({ ...prev, name: e.target.value }))}
                  placeholder="Nombre descriptivo"
                  required
                />
              </div>

              <div className="form-group">
                <label>Tipo de entrada:</label>
                <div className="input-mode-selector">
                  <label>
                    <input 
                      type="radio" 
                      value="file" 
                      checked={inputMode === 'file'} 
                      onChange={() => setInputMode('file')}
                    />
                    Subir archivo
                  </label>
                  <label>
                    <input 
                      type="radio" 
                      value="url" 
                      checked={inputMode === 'url'} 
                      onChange={() => setInputMode('url')}
                    />
                    Usar URL
                  </label>
                </div>
              </div>

              {inputMode === 'file' ? (
                <div key="add-file-input-group" className="form-group">
                  <label>Archivo (imagen o video) *</label>
                  <input
                    type="file"
                    accept="image/*,video/*"
                    onChange={handleFileChange}
                    required={inputMode === 'file'}
                  />
                  <small>Formatos permitidos: imágenes (jpg, png, gif) y videos (mp4, webm). Máximo 50MB.</small>
                </div>
              ) : (
                <div key="add-url-input-group" className="form-group">
                  <label>URL del asset *</label>
                  <input
                    type="text"
                    value={nuevoAsset.uri || ''}
                    onChange={e => setNuevoAsset(prev => ({ ...prev, uri: e.target.value || '' }))}
                    placeholder="https://ejemplo.com/imagen.jpg o http://ejemplo.com/video.mp4"
                    required={inputMode === 'url'}
                  />
                </div>
              )}

              <div className="form-group">
                <label>Mimetype *</label>
                <select
                  value={nuevoAsset.mimetype}
                  onChange={e => setNuevoAsset(prev => ({ ...prev, mimetype: e.target.value }))}
                  required
                >
                  <option value="">Selecciona un tipo</option>
                  <option value="image/jpeg">Imagen (JPEG)</option>
                  <option value="image/png">Imagen (PNG)</option>
                  <option value="image/gif">Imagen (GIF)</option>
                  <option value="video/mp4">Video (MP4)</option>
                  <option value="video/webm">Video (WebM)</option>
                </select>
              </div>

              <div className="form-group">
                <label>Duración (segundos)</label>
                <input
                  type="number"
                  value={nuevoAsset.duration}
                  onChange={e => setNuevoAsset(prev => ({ ...prev, duration: parseInt(e.target.value) || 60 }))}
                  placeholder="Duración en segundos"
                  min="0"
                />
              </div>

              <div className="form-row">
                <div className="form-group">
                  <label>Fecha de inicio</label>
                  <input
                    type="datetime-local"
                    value={nuevoAsset.start_date}
                    onChange={e => setNuevoAsset(prev => ({ ...prev, start_date: e.target.value }))}
                  />
                </div>

                <div className="form-group">
                  <label>Fecha de fin</label>
                  <input
                    type="datetime-local"
                    value={nuevoAsset.end_date}
                    onChange={e => setNuevoAsset(prev => ({ ...prev, end_date: e.target.value }))}
                  />
                </div>
              </div>

              <div className="modal-actions">
                <button 
                  type="button" 
                  onClick={() => {
                    limpiarFormulario();
                    setShowAddModal(false);
                  }}
                  className="btn-cancelar"
                  disabled={isUploading}
                >
                  Cancelar
                </button>
                <button 
                  type="submit" 
                  className="btn-guardar"
                  disabled={isUploading}
                >
                  Guardar Asset
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal para editar asset */}
      {showEditModal && (
        <div className="modal">
          <div className="modal-content">
            <h2>Editar Asset</h2>
            <form onSubmit={handleUpdate} className="asset-form">
              <div className="form-group">
                <label>Nombre del asset *</label>
                <input
                  type="text"
                  value={nuevoAsset.name}
                  onChange={e => setNuevoAsset(prev => ({ ...prev, name: e.target.value }))}
                  placeholder="Nombre descriptivo"
                  required
                />
              </div>

              <div className="form-group">
                <label>Tipo de entrada:</label>
                <div className="input-mode-selector">
                  <label>
                    <input 
                      type="radio" 
                      value="file" 
                      checked={inputMode === 'file'} 
                      onChange={() => setInputMode('file')}
                    />
                    Subir archivo
                  </label>
                  <label>
                    <input 
                      type="radio" 
                      value="url" 
                      checked={inputMode === 'url'} 
                      onChange={() => setInputMode('url')}
                    />
                    Usar URL
                  </label>
                </div>
              </div>

              {inputMode === 'file' ? (
                <div className="form-group">
                  <label>Archivo (opcional, para cambiar)</label>
                  <input
                    type="file"
                    accept="image/*,video/*"
                    onChange={handleFileChange}
                  />
                  <small>Deja en blanco para mantener el archivo actual. Formatos permitidos: imágenes (jpg, png, gif) y videos (mp4, webm). Máximo 50MB.</small>
                </div>
              ) : (
                <div key="edit-url-input-group" className="form-group">
                  <label>URL del asset *</label>
                  <input
                    type="text"
                    value={nuevoAsset.uri || ''}
                    onChange={e => setNuevoAsset(prev => ({ ...prev, uri: e.target.value || '' }))}
                    placeholder="https://ejemplo.com/imagen.jpg o http://ejemplo.com/video.mp4"
                    required={inputMode === 'url'}
                  />
                </div>
              )}

              <div className="form-group">
                <label>Mimetype *</label>
                <select
                  value={nuevoAsset.mimetype}
                  onChange={e => setNuevoAsset(prev => ({ ...prev, mimetype: e.target.value }))}
                  required
                >
                  <option value="">Selecciona un tipo</option>
                  <option value="image/jpeg">Imagen (JPEG)</option>
                  <option value="image/png">Imagen (PNG)</option>
                  <option value="image/gif">Imagen (GIF)</option>
                  <option value="video/mp4">Video (MP4)</option>
                  <option value="video/webm">Video (WebM)</option>
                </select>
              </div>

              <div className="form-group">
                <label>Duración (segundos)</label>
                <input
                  type="number"
                  value={nuevoAsset.duration}
                  onChange={e => setNuevoAsset(prev => ({ ...prev, duration: parseInt(e.target.value) || 60 }))}
                  placeholder="Duración en segundos"
                  min="0"
                />
              </div>

              <div className="form-row">
                <div className="form-group">
                  <label>Fecha de inicio</label>
                  <input
                    type="datetime-local"
                    value={nuevoAsset.start_date}
                    onChange={e => setNuevoAsset(prev => ({ ...prev, start_date: e.target.value }))}
                  />
                </div>

                <div className="form-group">
                  <label>Fecha de fin</label>
                  <input
                    type="datetime-local"
                    value={nuevoAsset.end_date}
                    onChange={e => setNuevoAsset(prev => ({ ...prev, end_date: e.target.value }))}
                  />
                </div>
              </div>

              <div className="form-group">
                <label>Activo</label>
                <input
                  type="checkbox"
                  checked={nuevoAsset.is_active === 1}
                  onChange={e => setNuevoAsset(prev => ({ ...prev, is_active: e.target.checked ? 1 : 0 }))}
                />
              </div>

              <div className="modal-actions">
                <button 
                  type="button" 
                  onClick={() => {
                    limpiarFormulario();
                    setShowEditModal(false);
                  }}
                  className="btn-cancelar"
                  disabled={isUploading}
                >
                  Cancelar
                </button>
                <button 
                  type="submit" 
                  className="btn-guardar"
                  disabled={isUploading}
                >
                  Guardar Cambios
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default ListaAssets;
