import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './GestionarCuenta.css';

const API_URL = 'http://localhost:3000/api';

// Configurar axios para incluir el token en todas las peticiones
axios.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

const GestionarCuenta = () => {
  const [usuarios, setUsuarios] = useState([]);
  const [error, setError] = useState(null);
  const [success, setSuccess] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [usuarioSeleccionado, setUsuarioSeleccionado] = useState(null);
  const [usuarioActual, setUsuarioActual] = useState(null);

  // Estado para el formulario
  const [formData, setFormData] = useState({
    usuario: '',
    nombre: '',
    apellidos: '',
    clave: '',
    rol: 'usuario'
  });

  // Cargar datos del usuario actual y lista de usuarios si es admin
  useEffect(() => {
    const cargarDatos = async () => {
      try {
        // Verificar si hay token
        const token = localStorage.getItem('token');
        if (!token) {
          setError('No hay sesión activa');
          setIsLoading(false);
          return;
        }

        const response = await axios.get(`${API_URL}/usuarios/perfil`);
        console.log('Datos del usuario actual:', response.data); // Debug
        setUsuarioActual(response.data.usuario);
        
        // Si es administrador, cargar lista de usuarios
        if (response.data.usuario.rol === 'administrador') {
          const usuariosResponse = await axios.get(`${API_URL}/usuarios`);
          console.log('Lista de usuarios:', usuariosResponse.data); // Debug
          setUsuarios(usuariosResponse.data.usuarios);
        }
        
        setError(null);
      } catch (error) {
        console.error('Error al cargar datos:', error);
        if (error.response?.status === 403) {
          setError('No tienes permisos para acceder a esta sección');
        } else if (error.response?.status === 401) {
          setError('Sesión expirada. Por favor, vuelve a iniciar sesión');
          // Opcional: redirigir al login
          // window.location.href = '/login';
        } else {
          setError('Error al cargar los datos: ' + (error.response?.data?.error || error.message));
        }
      } finally {
        setIsLoading(false);
      }
    };

    cargarDatos();
  }, []);

  // Si está cargando, mostrar mensaje
  if (isLoading) {
    return <div className="loading-message">Cargando datos...</div>;
  }

  // Si no es administrador, mostrar mensaje de acceso denegado
  if (!usuarioActual || usuarioActual.rol !== 'administrador') {
    return (
      <div className="acceso-denegado">
        <h2>Acceso Denegado</h2>
        <p>No tienes permisos para acceder a esta sección.</p>
        <p>Tu rol actual es: {usuarioActual?.rol || 'No definido'}</p>
      </div>
    );
  }

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError(null);
    setSuccess(null);

    try {
      if (usuarioSeleccionado) {
        // Actualizar usuario existente
        const response = await axios.put(`${API_URL}/usuarios/${usuarioSeleccionado.id}`, formData);
        setSuccess('Usuario actualizado correctamente');
      } else {
        // Crear nuevo usuario
        const response = await axios.post(`${API_URL}/usuarios`, formData);
        setSuccess('Usuario creado correctamente');
      }

      // Recargar lista de usuarios
      const usuariosResponse = await axios.get(`${API_URL}/usuarios`);
      setUsuarios(usuariosResponse.data.usuarios);

      // Cerrar modal y limpiar formulario
      setShowModal(false);
      setUsuarioSeleccionado(null);
      setFormData({
        usuario: '',
        nombre: '',
        apellidos: '',
        clave: '',
        rol: 'usuario'
      });
    } catch (error) {
      console.error('Error al guardar usuario:', error);
      setError(error.response?.data?.error || 'Error al guardar el usuario');
    }
  };

  const handleDelete = async (userId) => {
    try {
      await axios.delete(`${API_URL}/usuarios/${userId}`);
      setSuccess('Usuario eliminado correctamente');
      
      // Recargar lista de usuarios
      const usuariosResponse = await axios.get(`${API_URL}/usuarios`);
      setUsuarios(usuariosResponse.data.usuarios);
    } catch (error) {
      console.error('Error al eliminar usuario:', error);
      setError(error.response?.data?.error || 'Error al eliminar el usuario');
    }
  };

  // Si es administrador, mostrar la gestión de usuarios
  return (
    <div className="gestionar-cuenta">
      <div className="header-acciones">
        <h2>Gestión de Usuarios</h2>
        <button onClick={() => setShowModal(true)} className="btn-agregar">
          Agregar Usuario
        </button>
      </div>

      {error && (
        <div className="error-message">
          {error}
        </div>
      )}

      {success && (
        <div className="success-message">
          {success}
        </div>
      )}

      <div className="tabla-container">
        <table>
          <thead>
            <tr>
              <th>Usuario</th>
              <th>Nombre</th>
              <th>Apellidos</th>
              <th>Rol</th>
              <th>Fecha Creación</th>
              <th>Último acceso</th>
              <th>Acciones</th>
            </tr>
          </thead>
          <tbody>
            {usuarios.map(usuario => (
              <tr key={usuario.id}>
                <td>{usuario.usuario}</td>
                <td>{usuario.nombre || '-'}</td>
                <td>{usuario.apellidos || '-'}</td>
                <td>{usuario.rol === 'administrador' ? 'Administrador' : 'Usuario'}</td>
                <td>
                  {usuario.fecha_creacion 
                    ? new Date(usuario.fecha_creacion).toLocaleString('es-ES')
                    : '-'
                  }
                </td>
                <td>
                  {usuario.ultimo_acceso 
                    ? new Date(usuario.ultimo_acceso).toLocaleString('es-ES')
                    : 'Nunca'
                  }
                </td>
                <td>
                  <div className="acciones">
                    <button 
                      onClick={() => {
                        setUsuarioSeleccionado(usuario);
                        setFormData({
                          usuario: usuario.usuario,
                          nombre: usuario.nombre || '',
                          apellidos: usuario.apellidos || '',
                          clave: '',
                          rol: usuario.rol
                        });
                        setShowModal(true);
                      }}
                      className="btn-editar"
                    >
                      Editar
                    </button>
                    <button 
                      onClick={() => {
                        if (window.confirm('¿Estás seguro de que deseas eliminar este usuario?')) {
                          handleDelete(usuario.id);
                        }
                      }}
                      className="btn-eliminar"
                    >
                      Eliminar
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Modal para crear/editar usuario */}
      {showModal && (
        <div className="modal">
          <div className="modal-content">
            <h2>{usuarioSeleccionado ? 'Editar Usuario' : 'Crear Usuario'}</h2>
            <form onSubmit={handleSubmit} className="usuario-form">
              <div className="form-group">
                <label>Usuario *</label>
                <input
                  type="text"
                  value={formData.usuario}
                  onChange={e => setFormData(prev => ({ ...prev, usuario: e.target.value }))}
                  required
                  disabled={!!usuarioSeleccionado}
                />
              </div>

              <div className="form-group">
                <label>Nombre</label>
                <input
                  type="text"
                  value={formData.nombre}
                  onChange={e => setFormData(prev => ({ ...prev, nombre: e.target.value }))}
                />
              </div>

              <div className="form-group">
                <label>Apellidos</label>
                <input
                  type="text"
                  value={formData.apellidos}
                  onChange={e => setFormData(prev => ({ ...prev, apellidos: e.target.value }))}
                />
              </div>

              <div className="form-group">
                <label>{usuarioSeleccionado ? 'Nueva Contraseña' : 'Contraseña *'}</label>
                <input
                  type="password"
                  value={formData.clave}
                  onChange={e => setFormData(prev => ({ ...prev, clave: e.target.value }))}
                  required={!usuarioSeleccionado}
                />
                {usuarioSeleccionado && (
                  <small>Dejar en blanco para mantener la contraseña actual</small>
                )}
              </div>

              <div className="form-group">
                <label>Rol</label>
                <select
                  value={formData.rol}
                  onChange={e => setFormData(prev => ({ ...prev, rol: e.target.value }))}
                >
                  <option value="usuario">Usuario</option>
                  <option value="administrador">Administrador</option>
                </select>
              </div>

              <div className="modal-actions">
                <button 
                  type="button" 
                  onClick={() => {
                    setShowModal(false);
                    setUsuarioSeleccionado(null);
                    setFormData({
                      usuario: '',
                      nombre: '',
                      apellidos: '',
                      clave: '',
                      rol: 'usuario'
                    });
                    setError(null);
                  }}
                  className="btn-cancelar"
                >
                  Cancelar
                </button>
                <button 
                  type="submit" 
                  className="btn-guardar"
                >
                  {usuarioSeleccionado ? 'Actualizar' : 'Crear'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default GestionarCuenta; 