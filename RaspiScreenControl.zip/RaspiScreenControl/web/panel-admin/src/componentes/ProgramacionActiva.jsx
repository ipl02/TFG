//Componente para mostrar la programación activa de una pantalla
import React, { useEffect, useState } from 'react';
import axios from 'axios';

//Componente para mostrar la programación activa de una pantalla
const ProgramacionActiva = ({ pantallaId }) => {
  //Estado para almacenar el asset de la programación activa
  const [asset, setAsset] = useState(null);

  //Efecto para obtener el asset de la programación activa
  useEffect(() => {
    //Hace una petición GET a la API para obtener el asset de la programación activa
    axios.get(`http://localhost:3000/pantallas/${pantallaId}/programacion-activa`)
      .then(res => setAsset(res.data.asset))
      .catch(() => setAsset(null));
  }, [pantallaId]);

  //Si no hay asset, muestra un mensaje
  if (!asset) return <p>No hay programación activa.</p>;

  //Si hay asset, muestra el asset
  return (
    //Contenedor para mostrar el asset
    <div>
      <h3>Programación activa</h3>
      <p>{asset.name}</p>
      <img src={asset.uri} alt={asset.name} width="300" />
    </div>
  );
};

export default ProgramacionActiva;

