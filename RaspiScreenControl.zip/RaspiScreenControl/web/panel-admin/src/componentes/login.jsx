import React, { useState } from 'react';
import axios from 'axios';
import './login.css';

const Login = ({ onLogin }) => {
  const [usuario, setUsuario] = useState('');
  const [clave, setClave] = useState('');

  const handleSubmit = async () => {
    try {
      const res = await axios.post('http://localhost:3000/api/auth/login', { usuario, clave });
      localStorage.setItem('token', res.data.token);
      onLogin(res.data.user);
    } catch (err) {
      alert('Error al iniciar sesión. Verifica tus credenciales.');
    }
  };

  return (
    <div className="login-bg">
      <div className="login-container">
        <h1 className="login-title">Raspi Screen Control</h1>
        <p className="login-subtitle">Isabel Pineda Lozano</p>
        <img src="/logo.png" alt="logo" className="login-img" style={{width: '200px', margin: '5px auto'}} />
        <input
          type="text"
          placeholder="USUARIO"
          value={usuario}
          onChange={e => setUsuario(e.target.value)}
          className="login-input"
        />
        <input
          type="password"
          placeholder="CONTRASEÑA"
          value={clave}
          onChange={e => setClave(e.target.value)}
          className="login-input"
        />
        <button className="login-btn" onClick={handleSubmit}>INICIO SESIÓN</button>
      </div>
    </div>
  );
};

export default Login;
