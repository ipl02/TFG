import React, { useState } from 'react';
import axios from 'axios';

const AgregarAsset = () => {
  const [name, setName] = useState('');
  const [uri, setUri] = useState('');
  const [mimetype, setMimetype] = useState('');
  const [duration, setDuration] = useState('');
  const [endDate, setEndDate] = useState('');
  const [startDate, setStartDate] = useState('');

  const handleSubmit = () => {
    const now = new Date();
    const start_date = now.toISOString();
    const end_date = endDate ? new Date(endDate).toISOString() : null;
    axios.post('http://localhost:3000/assets', {
      name,
      uri,
      mimetype,
      duration: duration ? parseInt(duration) : null,
      start_date,
      end_date,
      is_active: 1,
      usuario_id: 1
    })
    .then(() => {
      alert('Asset añadido correctamente');
      setName('');
      setUri('');
      setMimetype('');
      setDuration('');
      setEndDate('');
      setStartDate('');
    })
    .catch(err => {
      console.error(err);
      alert('Error al añadir asset');
    });
  };

  return (
    <div>
      <h3>Añadir Asset</h3>
      <input type="text" placeholder="Nombre" value={name} onChange={e => setName(e.target.value)} />
      <br />
      <input type="text" placeholder="URL o ruta del archivo" value={uri} onChange={e => setUri(e.target.value)} />
      <br />
      <input type="text" placeholder="Mimetype (image/png o video/mp4)" value={mimetype} onChange={e => setMimetype(e.target.value)} />
      <br />
      <input type="number" placeholder="Duración (segundos)" value={duration} onChange={e => setDuration(e.target.value)} />
      <br />
      <label>Fecha de inicio:</label>
      <input type="datetime-local" value={startDate} onChange={e => setEndDate(e.target.value)} />
      <br />
      <label>Fecha de fin (opcional):</label>
      <input type="datetime-local" value={endDate} onChange={e => setEndDate(e.target.value)} />
      <br />
      <button onClick={handleSubmit}>Añadir Asset</button>
    </div>
  );
};

export default AgregarAsset;
