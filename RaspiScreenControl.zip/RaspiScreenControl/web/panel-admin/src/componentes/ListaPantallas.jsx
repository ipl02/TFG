//Componente para mostrar la lista de pantallas 
//Importa React, useEffect y useState para manejar el estado y el ciclo de vida del componente
import React, { useEffect, useState } from 'react'; 
//Importa axios para hacer peticiones HTTP
import axios from 'axios'; 
import './ListaPantallas.css';

// Definir la URL base de la API
const API_URL = 'http://localhost:3000/api';

// Configuración base de Axios
axios.defaults.baseURL = 'http://localhost:3000';
axios.defaults.headers.common['Content-Type'] = 'application/json';

// Interceptor para añadir el token a todas las solicitudes
axios.interceptors.request.use(
  config => {
    const token = localStorage.getItem('token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  error => Promise.reject(error)
);
 
const ListaPantallas = ({ onSeleccionarPantalla }) => {
  const [pantallas, setPantallas] = useState([]);
  const [error, setError] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [editandoPantalla, setEditandoPantalla] = useState(null);
  const [showEditModal, setShowEditModal] = useState(false);
  const [showAddModal, setShowAddModal] = useState(false);
  const [filtroEstado, setFiltroEstado] = useState('todos'); // 'todos', 'activa', 'inactiva'
  
  // Estados para el formulario de nueva pantalla
  const [nuevaPantalla, setNuevaPantalla] = useState({
    nombre: '',
    direccion_IP: '',
    estado: 'activa',
    ubicacion: 'sin ubicación'
  });

  // Efecto para controlar el scroll del body cuando cualquier modal está abierto
  useEffect(() => {
    if (showAddModal || showEditModal) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'unset';
    }
    return () => {
      document.body.style.overflow = 'unset';
    };
  }, [showAddModal, showEditModal]);

  // Cargar pantallas
  const cargarPantallas = async () => {
    setError(null);
    setIsLoading(true);
    try {
      const response = await axios.get(`${API_URL}/pantallas`);
      console.log('Pantallas cargadas:', response.data);
      setPantallas(response.data);
    } catch (error) {
      console.error('Error al cargar pantallas:', error);
      setError('Error al cargar las pantallas. Por favor, inténtalo de nuevo.');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    cargarPantallas();
  }, []);

  // Eliminar pantalla
  const eliminarPantalla = async (id) => {
    if (!window.confirm('¿Estás seguro de que quieres eliminar esta pantalla?')) {
      return;
    }

    setError(null);
    try {
      const response = await axios.delete(`${API_URL}/pantallas/${id}`);
      console.log('Pantalla eliminada:', response.data);
      await cargarPantallas();
    } catch (error) {
      console.error('Error al eliminar pantalla:', error);
      setError(error.response?.data?.error || 'Error al eliminar la pantalla. Por favor, inténtalo de nuevo.');
    }
  };

  // Filtrar pantallas según el estado seleccionado
  const pantallasFiltradas = pantallas.filter(pantalla => {
    if (filtroEstado === 'todos') return true;
    if (filtroEstado === 'activa') return pantalla.estado === 'activa';
    if (filtroEstado === 'inactiva') return pantalla.estado === 'inactiva';
    return true;
  });

  // Función para limpiar el formulario de agregar/editar
  const limpiarFormulario = () => {
    setNuevaPantalla({
      nombre: '',
      direccion_IP: '',
      estado: 'activa',
      ubicacion: 'sin ubicación'
    });
    setEditandoPantalla(null);
    setError(null);
  };

  // Función para cargar una pantalla para editar
  const cargarPantallaParaEditar = (pantalla) => {
    setEditandoPantalla(pantalla);
    setNuevaPantalla({
      nombre: pantalla.nombre || '',
      direccion_IP: pantalla.direccion_IP || '',
      estado: pantalla.estado || 'activa',
      ubicacion: pantalla.ubicacion || 'sin ubicación'
    });
    setShowEditModal(true);
  };

  // Función para validar los datos antes de enviar
  const validarDatos = () => {
    const errores = [];

    if (!nuevaPantalla.nombre) {
      errores.push('El nombre de la pantalla es requerido');
    }

    if (!nuevaPantalla.direccion_IP) {
      errores.push('La dirección IP es requerida');
    }

    const ipRegex = /^(\d{1,3}\.){3}\d{1,3}(:\d+)?$/;
    if (!ipRegex.test(nuevaPantalla.direccion_IP)) {
      errores.push('La dirección IP debe tener un formato válido (ejemplo: 192.168.1.1 o 192.168.1.1:8080)');
    }

    return errores.length === 0;
  };

  // Función para manejar el envío del formulario de edición
  const handleUpdate = async (e) => {
    e.preventDefault();
    console.log('handleUpdate: Iniciando actualización...');
    console.log('handleUpdate: Estado actual de nuevaPantalla:', nuevaPantalla);
    console.log('handleUpdate: Estado actual de editandoPantalla:', editandoPantalla);

    setError(null);

    const isValid = validarDatos();
    console.log('handleUpdate: Resultado de validarDatos():', isValid);

    if (!isValid) {
      console.log('handleUpdate: Validación fallida, cancelando actualización.');
      return;
    }

    try {
      const pantallaData = {
        nombre: nuevaPantalla.nombre,
        direccion_IP: nuevaPantalla.direccion_IP,
        estado: nuevaPantalla.estado,
        ubicacion: nuevaPantalla.ubicacion
      };

      console.log('handleUpdate: Enviando datos al servidor:', pantallaData);

      const response = await axios.put(`${API_URL}/pantallas/${editandoPantalla.id}`, pantallaData);
      console.log('handleUpdate: Respuesta del servidor:', response.data);
      
      setShowEditModal(false);
      limpiarFormulario();
      await cargarPantallas();
      console.log('handleUpdate: Pantalla actualizada y lista recargada');

    } catch (error) {
      console.error('handleUpdate: Error al actualizar pantalla:', error);
      setError(error.response?.data?.error || 'Error al actualizar la pantalla. Por favor, inténtalo de nuevo.');
    }
  };

  // Función para manejar el envío del formulario de agregar
  const handleSubmit = async (e) => {
    e.preventDefault();
    setError(null);

    if (!validarDatos()) {
      return;
    }

    try {
      const pantallaData = {
        nombre: nuevaPantalla.nombre,
        direccion_IP: nuevaPantalla.direccion_IP,
        estado: nuevaPantalla.estado,
        ubicacion: nuevaPantalla.ubicacion
      };

      const response = await axios.post(`${API_URL}/pantallas`, pantallaData);
      setShowAddModal(false);
      limpiarFormulario();
      await cargarPantallas();
    } catch (error) {
      setError(error.response?.data?.error || 'Error al crear la pantalla');
    }
  };

  //Renderiza el componente     
  return (
    <div className="lista-pantallas">
      <div className="pantallas-header">
        <h2>Gestión de Pantallas</h2>
        <div className="pantallas-controls">
          <select 
            value={filtroEstado} 
            onChange={(e) => setFiltroEstado(e.target.value)}
            className="filtro-estado"
          >
            <option value="todos">Todos los estados</option>
            <option value="activa">Solo activas</option>
            <option value="inactiva">Solo inactivas</option>
          </select>
          <button 
            onClick={() => { setShowAddModal(true); limpiarFormulario(); }}
            className="btn-agregar"
          >
            Agregar Pantalla
          </button>
        </div>
      </div>

      {error && (
        <div className="error-message">
          {error}
        </div>
      )}

      {isLoading ? (
        <div className="loading-message">Cargando pantallas...</div>
      ) : (
        <div className="pantallas-list">
          {pantallasFiltradas.length > 0 ? (
            <table>
              <thead>
                <tr>
                  <th>ID</th>
                  <th>Nombre</th>
                  <th>Dirección IP</th>
                  <th>Ubicación</th>
                  <th>Estado</th>
                  <th>Acciones</th>
                </tr>
              </thead>
              <tbody>
                {pantallasFiltradas.map(pantalla => (
                  <tr key={pantalla.id}>
                    <td>{pantalla.id}</td>
                    <td>{pantalla.nombre}</td>
                    <td>{pantalla.direccion_IP}</td>
                    <td>{pantalla.ubicacion}</td>
                    <td>
                      <span className={`estado-badge ${pantalla.estado === 'activa' ? 'activo' : 'inactivo'}`}>
                        {pantalla.estado === 'activa' ? 'Activa' : 'Inactiva'}
                      </span>
                    </td>
                    <td>
                      <button 
                        onClick={() => cargarPantallaParaEditar(pantalla)}
                        className="btn-editar"
                      >
                        Editar
                      </button>
                      <button 
                        onClick={() => eliminarPantalla(pantalla.id)}
                        className="btn-eliminar"
                      >
                        Eliminar
            </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          ) : (
            <p>No hay pantallas disponibles</p>
          )}
        </div>
      )}

      {/* Modal para agregar pantalla */}
      {showAddModal && (
        <div className="modal">
          <div className="modal-content">
            <h2>Agregar Nueva Pantalla</h2>
            <form onSubmit={handleSubmit} className="pantalla-form">
              <div className="form-group">
                <label>Nombre de la pantalla *</label>
                <input
                  type="text"
                  value={nuevaPantalla.nombre}
                  onChange={e => setNuevaPantalla(prev => ({ ...prev, nombre: e.target.value }))}
                  placeholder="Nombre descriptivo"
                  required
                />
              </div>

              <div className="form-group">
                <label>Dirección IP *</label>
                <input
                  type="text"
                  value={nuevaPantalla.direccion_IP}
                  onChange={e => setNuevaPantalla(prev => ({ ...prev, direccion_IP: e.target.value }))}
                  placeholder="192.168.1.1 o 192.168.1.1:8080"
                  required
                />
                <small>Formato: IP o IP:puerto (ejemplo: 192.168.1.1:8080)</small>
              </div>

              <div className="form-group">
                <label>Ubicación</label>
                <input
                  type="text"
                  value={nuevaPantalla.ubicacion}
                  onChange={e => setNuevaPantalla(prev => ({ ...prev, ubicacion: e.target.value }))}
                  placeholder="Ubicación de la pantalla"
                />
              </div>

              <div className="form-group">
                <label>Estado</label>
                <select
                  value={nuevaPantalla.estado}
                  onChange={e => setNuevaPantalla(prev => ({ ...prev, estado: e.target.value }))}
                >
                  <option value="activa">Activa</option>
                  <option value="inactiva">Inactiva</option>
                </select>
              </div>

              <div className="modal-actions">
                <button 
                  type="button" 
                  onClick={() => {
                    limpiarFormulario();
                    setShowAddModal(false);
                  }}
                  className="btn-cancelar"
                >
                  Cancelar
                </button>
                <button 
                  type="submit" 
                  className="btn-guardar"
                >
                  Guardar Pantalla
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal para editar pantalla */}
      {showEditModal && (
        <div className="modal">
          <div className="modal-content">
            <h2>Editar Pantalla</h2>
            <form onSubmit={handleUpdate} className="pantalla-form">
              <div className="form-group">
                <label>Nombre de la pantalla *</label>
                <input
                  type="text"
                  value={nuevaPantalla.nombre}
                  onChange={e => setNuevaPantalla(prev => ({ ...prev, nombre: e.target.value }))}
                  placeholder="Nombre descriptivo"
                  required
                />
              </div>

              <div className="form-group">
                <label>Dirección IP *</label>
                <input
                  type="text"
                  value={nuevaPantalla.direccion_IP}
                  onChange={e => setNuevaPantalla(prev => ({ ...prev, direccion_IP: e.target.value }))}
                  placeholder="192.168.1.1 o 192.168.1.1:8080"
                  required
                />
                <small>Formato: IP o IP:puerto (ejemplo: 192.168.1.1:8080)</small>
              </div>

              <div className="form-group">
                <label>Ubicación</label>
                <input
                  type="text"
                  value={nuevaPantalla.ubicacion}
                  onChange={e => setNuevaPantalla(prev => ({ ...prev, ubicacion: e.target.value }))}
                  placeholder="Ubicación de la pantalla"
                />
              </div>

              <div className="form-group">
                <label>Estado</label>
                <select
                  value={nuevaPantalla.estado}
                  onChange={e => setNuevaPantalla(prev => ({ ...prev, estado: e.target.value }))}
                >
                  <option value="activa">Activa</option>
                  <option value="inactiva">Inactiva</option>
                </select>
              </div>
              <div className="modal-actions">
                <button 
                  type="button" 
                  onClick={() => {
                    limpiarFormulario();
                    setShowEditModal(false);
                  }}
                  className="btn-cancelar"
                >
                  Cancelar
                </button>
                <button 
                  type="submit" 
                  className="btn-guardar"
                >
                  Guardar Cambios
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default ListaPantallas;
