import React, { useEffect, useState } from 'react';
import axios from 'axios';

const ListaProgramaciones = () => {
  const [programaciones, setProgramaciones] = useState([]);
  const [error, setError] = useState(null);

  const cargarProgramaciones = () => {
    setError(null);
    axios.get('http://localhost:3000/programacion')
      .then(res => {
        console.log('Programaciones recibidas:', res.data);
        setProgramaciones(res.data);
      })
      .catch(err => {
        console.error('Error al cargar programaciones:', err);
        setError('Error al cargar las programaciones');
      });
  };

  useEffect(() => {
    cargarProgramaciones();
  }, []);

  const toggleEstado = (id, isEnabledActual) => {
    axios.put(`http://localhost:3000/programacion/${id}`, {
      is_enabled: isEnabledActual ? 0 : 1
    })
    .then(() => cargarProgramaciones())
    .catch(err => {
      console.error('Error al cambiar estado:', err);
      setError('Error al cambiar el estado de la programación');
    });
  };

  // Función para formatear fechas de manera segura
  const formatDate = (dateString) => {
    if (!dateString) return 'Fecha no disponible';
    try {
      const date = new Date(dateString);
      if (isNaN(date.getTime())) {
        console.error('Fecha inválida:', dateString);
        return 'Fecha inválida';
      }
      return date.toLocaleString('es-ES', {
        year: 'numeric',
        month: '2-digit',
        day: '2-digit',
        hour: '2-digit',
        minute: '2-digit',
        hour12: false
      });
    } catch (err) {
      console.error('Error al formatear fecha:', err);
      return 'Error en fecha';
    }
  };

  return (
    <div>
      <h3>Lista de Programaciones</h3>
      {error && <div className="error-message">{error}</div>}
      <table border="1" cellPadding="5" cellSpacing="0">
        <thead>
          <tr>
            <th>Pantalla</th>
            <th>Asset</th>
            <th>Inicio</th>
            <th>Fin</th>
            <th>Orden</th>
            <th>Activo</th>
            <th>Acciones</th>
          </tr>
        </thead>
        <tbody>
          {programaciones.map(prog => (
            <tr key={prog.id}>
              <td>{prog.pantalla_nombre || 'N/A'}</td>
              <td>{prog.asset_nombre || 'N/A'}</td>
              <td>{formatDate(prog.start_date)}</td>
              <td>{formatDate(prog.end_date)}</td>
              <td>{prog.play_order}</td>
              <td>{prog.is_enabled ? 'Sí' : 'No'}</td>
              <td>
                <button onClick={() => toggleEstado(prog.id, prog.is_enabled)}>
                  {prog.is_enabled ? 'Desactivar' : 'Activar'}
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default ListaProgramaciones;
