//Componente para agregar una pantalla
import React, { useState } from 'react';  
import axios from 'axios';

const AgregarPantalla = () => {
  const [nombre, setNombre] = useState('');
  const [direccion_IP, setIp] = useState('');
  const [estado, setEstado] = useState('activa'); // Valor por defecto
  const [ubicacion, setUbicacion] = useState('');

  const handleSubmit = () => {
    axios.post('http://localhost:3000/pantallas', {
      nombre,
      direccion_IP,
      estado,
      ubicacion
    })
    .then(() => {
      alert('Pantalla añadida correctamente');
      setNombre('');
      setIp('');
      setEstado('activa');
      setUbicacion('');
    })
    .catch(err => {
      console.error(err);
      alert('Error al añadir pantalla');
    });
  };

  return (
    <div>
      <h3>Añadir Pantalla</h3>
      <input type="text" placeholder="Nombre de la pantalla" value={nombre} onChange={e => setNombre(e.target.value)} />
      <br />
      <input type="text" placeholder="Dirección IP" value={direccion_IP} onChange={e => setIp(e.target.value)} />
      <br />
      <input type="text" placeholder="Ubicación" value={ubicacion} onChange={e => setUbicacion(e.target.value)} />
      <br />
      <select value={estado} onChange={e => setEstado(e.target.value)}>
        <option value="activa">Activa</option>
        <option value="inactiva">Inactiva</option>
      </select>
      <br />
      <button onClick={handleSubmit}>Añadir Pantalla</button>
    </div>
  );
};

export default AgregarPantalla;
