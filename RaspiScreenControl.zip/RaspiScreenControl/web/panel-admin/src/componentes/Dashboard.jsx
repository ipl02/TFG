import React, { useEffect, useState } from 'react';
import axios from 'axios';
import './Dashboard.css';
import Calendar from 'react-calendar';
import 'react-calendar/dist/Calendar.css';

const Dashboard = () => {
  const [pantallas, setPantallas] = useState([]);
  const [assets, setAssets] = useState([]);
  const [programaciones, setProgramaciones] = useState([]);
  const [fechaSeleccionada, setFechaSeleccionada] = useState(null);

  useEffect(() => {
    // Obtener pantallas
    const token = localStorage.getItem('token');
    axios.get('http://localhost:3000/api/pantallas', {
      headers: { Authorization: `Bearer ${token}` }
    })
      .then(res => setPantallas(res.data))
      .catch(() => setPantallas([]));
    // Obtener assets
    axios.get('http://localhost:3000/api/assets', {
      headers: { Authorization: `Bearer ${token}` }
    })
      .then(res => setAssets(res.data))
      .catch(() => setAssets([]));
    // Obtener programaciones
    axios.get('http://localhost:3000/api/programacion', {
      headers: { Authorization: `Bearer ${token}` }
    })
      .then(res => setProgramaciones(res.data))
      .catch(() => setProgramaciones([]));
  }, []);

  // Calcular totales
  const activas = pantallas.filter(p => p.estado === 'activa').length;
  const inactivas = pantallas.filter(p => p.estado !== 'activa').length;
  const imagenes = assets.filter(a => a.mimetype && a.mimetype.startsWith('image')).length;
  const videos = assets.filter(a => a.mimetype && a.mimetype.startsWith('video')).length;

  // Función para formatear fechas de manera segura
  const formatDate = (dateString) => {
    if (!dateString) return 'Fecha no disponible';
    try {
      const date = new Date(dateString);
      if (isNaN(date.getTime())) {
        console.error('Fecha inválida:', dateString);
        return 'Fecha inválida';
      }
      return date.toLocaleString('es-ES', {
        year: 'numeric',
        month: '2-digit',
        day: '2-digit',
        hour: '2-digit',
        minute: '2-digit',
        hour12: false
      });
    } catch (err) {
      console.error('Error al formatear fecha:', err);
      return 'Error en fecha';
    }
  };

  // Función para comparar fechas de manera segura
  const compareDates = (date1, date2) => {
    try {
      const d1 = new Date(date1);
      const d2 = new Date(date2);
      if (isNaN(d1.getTime()) || isNaN(d2.getTime())) {
        console.error('Fechas inválidas para comparar:', { date1, date2 });
        return 0;
      }
      return d1.getTime() - d2.getTime();
    } catch (err) {
      console.error('Error al comparar fechas:', err);
      return 0;
    }
  };

  // Filtrar programaciones
  let filteredProgramaciones = programaciones.filter(p => {
    // Solo programaciones habilitadas y activas
    if (p.is_enabled !== 1 || p.estado !== 'activo') return false;

    try {
      const now = new Date();
      const startDate = new Date(p.start_date);
      const endDate = new Date(p.end_date);

      if (isNaN(startDate.getTime()) || isNaN(endDate.getTime())) {
        console.error('Fechas inválidas en programación:', p);
        return false;
      }

      if (fechaSeleccionada) {
        // Si hay fecha seleccionada, mostrar las programaciones de ese día
        const selectedDate = new Date(fechaSeleccionada);
        selectedDate.setHours(0, 0, 0, 0);
        const nextDay = new Date(selectedDate);
        nextDay.setDate(selectedDate.getDate() + 1);

        // Una programación está en el día seleccionado si:
        // - Comienza antes del final del día seleccionado Y
        // - Termina después del inicio del día seleccionado
        return startDate < nextDay && endDate >= selectedDate;
      } else {
        // Si no hay fecha seleccionada, mostrar las próximas programaciones
        return startDate > now;
      }
    } catch (err) {
      console.error('Error al filtrar programación:', err);
      return false;
    }
  });

  // Ordenar por fecha de inicio
  filteredProgramaciones.sort((a, b) => compareDates(a.start_date, b.start_date));

  // Limitar a las próximas 3 programaciones si no hay fecha seleccionada
  let proximasMostrar = fechaSeleccionada ? filteredProgramaciones : filteredProgramaciones.slice(0, 3);

  // Función para obtener el nombre del asset
  const getAssetName = (programacion) => {
    if (programacion.asset_name) return programacion.asset_name;
    const asset = assets.find(a => a.id === programacion.asset_id);
    return asset ? asset.name : 'Asset no encontrado';
  };

  // Función para manejar el cambio de fecha en el calendario
  const handleDateChange = (date) => {
    if (date === null) {
      setFechaSeleccionada(null);
      return;
    }
    const year = date.getFullYear();
    const month = (date.getMonth() + 1).toString().padStart(2, '0');
    const day = date.getDate().toString().padStart(2, '0');
    setFechaSeleccionada(`${year}-${month}-${day}`);
  };

  // Función para marcar días con programaciones en el calendario
  const tileClassName = ({ date }) => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const currentDate = new Date(date);
    currentDate.setHours(0, 0, 0, 0);

    // Marcar el día actual
    if (currentDate.getTime() === today.getTime()) {
      return 'react-calendar__tile--today';
    }

    // Marcar días con programaciones
    const tieneProgramacion = programaciones.some(p => {
      if (p.is_enabled !== 1 || p.estado !== 'activo') return false;
      const startDate = new Date(p.start_date);
      const endDate = new Date(p.end_date);
      startDate.setHours(0, 0, 0, 0);
      endDate.setHours(0, 0, 0, 0);
      return currentDate >= startDate && currentDate <= endDate;
    });

    return tieneProgramacion ? 'react-calendar__tile--has-programacion' : null;
  };

  return (
    <div className="dashboard-main">
      <h1 className="dashboard-title">Dashboard</h1>
      <div className="dashboard-top">
        <div className="dashboard-right">
          <div className="dashboard-calendar">
            <Calendar
              onChange={handleDateChange}
              value={fechaSeleccionada ? new Date(fechaSeleccionada) : null}
              locale="es-ES"
              tileClassName={tileClassName}
              clearIcon={null} // Ocultar el icono de limpiar
            />
            {fechaSeleccionada && (
              <button 
                className="clear-date-button"
                onClick={() => setFechaSeleccionada(null)}
              >
                Mostrar próximas programaciones
              </button>
            )}
          </div>
        </div>
        <div className="dashboard-cards">
          <div className="dashboard-card green">
            <img src="/activas.png" alt="activas" className="icon-inline" />
            <div>
              <div className="dashboard-card-num">{activas}</div>
              <div>Activas</div>
            </div>
          </div>
          <div className="dashboard-card red">
            <img src="/inactivas.png" alt="inactivas" className="icon-inline" />
            <div>
              <div className="dashboard-card-num">{inactivas}</div>
              <div>Inactivas</div>
            </div>
          </div>
          <div className="dashboard-card dark">
            <img src="/videos.png" alt="videos" className="icon-inline" />
            <div>
              <div className="dashboard-card-num">{videos}</div>
              <div>Vídeos</div>
            </div>
          </div>
          <div className="dashboard-card dark">
            <img src="/image.png" alt="imagen" className="icon-inline" />
            <div>
              <div className="dashboard-card-num">{imagenes}</div>
              <div>Imágenes</div>
            </div>
          </div>
        </div>
      </div>
      <div className="dashboard-proximas">
        <h3>{fechaSeleccionada ? 'Programaciones del día' : 'Próximas programaciones'}</h3>
        <ul>
          {proximasMostrar.length === 0 ? (
            <li>No hay programaciones {fechaSeleccionada ? 'para esta fecha' : 'próximas'}</li>
          ) : (
            proximasMostrar.map((p, i) => (
              <li key={i}>
                <img src="/play.png" alt="play" className="play-icon" />
                <b>{p.pantalla_nombre || 'Pantalla no encontrada'}</b> - 
                {getAssetName(p)}
                <span className="dashboard-fecha">
                  {formatDate(p.start_date)}
                </span>
              </li>
            ))
          )}
        </ul>
      </div>
    </div>
  );
};

export default Dashboard; 