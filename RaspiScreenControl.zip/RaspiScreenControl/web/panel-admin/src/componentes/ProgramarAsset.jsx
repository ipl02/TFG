import React, { useEffect, useState } from 'react';
import axios from 'axios';
import './ProgramarAsset.css';

// Definir la URL base de la API
const API_URL = 'http://localhost:3000/api';

// Configuración base de Axios
axios.defaults.baseURL = 'http://localhost:3000';
axios.defaults.headers.common['Content-Type'] = 'application/json';

// Interceptor para añadir el token a todas las solicitudes
axios.interceptors.request.use(
  config => {
    const token = localStorage.getItem('token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  error => Promise.reject(error)
);

const ProgramarAsset = ({ userId }) => {
  const [assets, setAssets] = useState([]);
  const [pantallas, setPantallas] = useState([]);
  const [assetId, setAssetId] = useState('');
  const [pantallaIds, setPantallaIds] = useState([]);
  const [start, setStart] = useState(null); // Almacenará Date object en la zona horaria local
  const [end, setEnd] = useState(null);   // Almacenará Date object en la zona horaria local
  const [programaciones, setProgramaciones] = useState([]);
  const [editandoProgramacion, setEditandoProgramacion] = useState(null);
  const [showEditModal, setShowEditModal] = useState(false);
  const token = localStorage.getItem('token');

  // Función auxiliar para formatear una fecha (objeto Date en local) a string para datetime-local input
  const formatLocalDateToInput = (date) => {
    if (!date) return '';
    const year = date.getFullYear();
    const month = (date.getMonth() + 1).toString().padStart(2, '0');
    const day = date.getDate().toString().padStart(2, '0');
    const hours = date.getHours().toString().padStart(2, '0');
    const minutes = date.getMinutes().toString().padStart(2, '0');
    return `${year}-${month}-${day}T${hours}:${minutes}`;
  };

  // Función para cargar programaciones
  const cargarProgramaciones = async () => {
    try {
      const response = await axios.get(`${API_URL}/programacion`);
      // Backend ahora envía fechas como ISO strings con 'Z' (UTC)
      const programacionesData = Array.isArray(response.data) ? response.data : response.data.programaciones;

      if (programacionesData && Array.isArray(programacionesData)) {
        // Al cargar programaciones, convertir fechas UTC del backend a objetos Date locales para visualización
        const processedProgramaciones = programacionesData.map(p => ({
          ...p,
          // `new Date(isoString)` con 'Z' al final ya se interpreta como UTC, y los métodos getHours() etc. se ajustan a la hora local.
          // Si el backend ya devuelve con 'Z', new Date() es suficiente.
          start_date: p.start_date ? new Date(p.start_date) : null,
          end_date: p.end_date ? new Date(p.end_date) : null
        }));
        setProgramaciones(processedProgramaciones);
        console.log('Programaciones cargadas:', processedProgramaciones);
      } else {
        console.error('Formato de respuesta inesperado:', response.data);
        setProgramaciones([]);
      }
    } catch (error) {
      console.error('Error al cargar programaciones:', error);
      if (error.response) {
        console.error('Detalles del error:', error.response.data);
      }
      setProgramaciones([]);
    }
  };

  // Cargar datos iniciales
  useEffect(() => {
    const cargarDatos = async () => {
      try {
        const [assetsRes, pantallasRes] = await Promise.all([
          axios.get(`${API_URL}/assets`),
          axios.get(`${API_URL}/pantallas`)
        ]);
        setAssets(assetsRes.data);
        setPantallas(pantallasRes.data);
        await cargarProgramaciones();
      } catch (error) {
        console.error('Error al cargar datos iniciales:', error);
        alert('Error al cargar datos: ' + (error.response?.data?.error || error.message));
      }
    };
    cargarDatos();
  }, []);

  // Función para validar los datos antes de enviar
  const validarDatos = () => {
    const ahora = new Date();
    const errores = [];

    if (!assetId) {
      errores.push('Debe seleccionar un asset');
    }

    if (pantallaIds.length === 0) {
      errores.push('Debe seleccionar al menos una pantalla');
    }

    if (!start) {
      errores.push('Debe seleccionar una fecha de inicio');
    } else {
      const startLocal = new Date(start);
      if (!editandoProgramacion && startLocal < ahora) {
        errores.push('La fecha de inicio no puede ser anterior a la fecha actual');
      }
    }

    if (!end) {
      errores.push('Debe seleccionar una fecha de fin');
    } else {
      const endLocal = new Date(end);
      const startLocal = new Date(start);
      if (endLocal <= startLocal) {
        errores.push('La fecha de fin debe ser posterior a la fecha de inicio');
      }
    }

    return errores;
  };

  // Función para enviar la programación
  const enviarProgramacion = async () => {
    const errores = validarDatos();
    if (errores.length > 0) {
      alert('Por favor, corrija los siguientes errores:\n\n' + errores.join('\n'));
      return;
    }

    try {
      const startDate = new Date(start);
      const endDate = new Date(end);

      const response = await axios.post(`${API_URL}/programacion`, {
        pantalla_ids: pantallaIds,
        asset_id: parseInt(assetId),
        is_enabled: 1,
        play_order: 0,
        start_date: startDate.toISOString(),
        end_date: endDate.toISOString(),
        estado: 'activo',
        created_by: userId,
      });

      setAssetId('');
      setPantallaIds([]);
      setStart(null);
      setEnd(null);
      await cargarProgramaciones();

    } catch (error) {
      alert('Error al crear programación: ' + (error.response?.data?.error || error.message));
    }
  };

  // Función para actualizar una programación
  const actualizarProgramacion = async () => {
    if (!editandoProgramacion || !token) {
      alert('No hay sesión activa o programación seleccionada');
      return;
    }

    const errores = validarDatos();
    if (errores.length > 0) {
      alert('Por favor, corrija los siguientes errores:\n\n' + errores.join('\n'));
      return;
    }

    try {
      // Convertir las fechas a ISO string manteniendo la hora local
      const startDate = new Date(start);
      const endDate = new Date(end);

      console.log('Actualizando programación:', {
        id: editandoProgramacion.id,
        fechas: {
          inicio: {
            local: startDate.toLocaleString(),
            utc: startDate.toISOString(),
            hora_local: startDate.getHours()
          },
          fin: {
            local: endDate.toLocaleString(),
            utc: endDate.toISOString(),
            hora_local: endDate.getHours()
          }
        }
      });

      const response = await axios.put(`${API_URL}/programacion/${editandoProgramacion.id}`, {
        pantalla_id: pantallaIds[0],
        asset_id: assetId,
        start_date: startDate.toISOString(),
        end_date: endDate.toISOString(),
        play_order: 0,
        is_enabled: 1,
        estado: 'activo'
      });

      console.log('Programación actualizada:', response.data);
      setEditandoProgramacion(null);
      setShowEditModal(false);
      setAssetId('');
      setPantallaIds([]);
      setStart(null);
      setEnd(null);
      await cargarProgramaciones();

    } catch (error) {
      console.error('Error al actualizar programación:', error);
      if (error.response?.status === 401) {
        alert('La sesión ha expirado. Por favor, inicie sesión nuevamente.');
      } else {
        alert('Error al actualizar la programación: ' + (error.response?.data?.error || error.message));
      }
    }
  };

  // Función para cargar programación para editar
  const cargarProgramacionParaEditar = (programacion) => {
    setEditandoProgramacion(programacion);
    setAssetId(programacion.asset_id.toString());
    setPantallaIds([programacion.pantalla_id]);
    // Convertir fecha UTC de backend a Date local para el formulario de edición
    setStart(programacion.start_date ? new Date(programacion.start_date) : null);
    setEnd(programacion.end_date ? new Date(programacion.end_date) : null);
    setShowEditModal(true);
  };

  // Función para cancelar edición
  const cancelarEdicion = () => {
    setEditandoProgramacion(null);
    setShowEditModal(false);
    setAssetId('');
    setPantallaIds([]);
    setStart(null);
    setEnd(null);
  };

  // Función para eliminar programación
  const eliminarProgramacion = async (id) => {
    if (!confirm('¿Está seguro de eliminar esta programación?')) return;

    try {
      await axios.delete(`${API_URL}/programacion/${id}`);
      await cargarProgramaciones();
    } catch (error) {
      console.error('Error al eliminar programación:', error);
      alert('Error al eliminar programación: ' + (error.response?.data?.error || error.message));
    }
  };

  return (
    <div className="programar-asset">
      <h2>Programar Asset</h2>

      {/* Sección para seleccionar pantallas */}
      <div className="form-group">
        <label>Selecciona pantallas:</label>
        <div className="pantallas-grid">
        {pantallas.map(p => (
            <label key={p.id} className="pantalla-checkbox">
            <input
              type="checkbox"
              value={p.id}
                onChange={e => {
                  const id = parseInt(e.target.value);
                  setPantallaIds(prev =>
                    e.target.checked
                      ? [...prev, id]
                      : prev.filter(p => p !== id)
                  );
                }}
                checked={pantallaIds.includes(p.id)}
            />
            {p.nombre}
          </label>
        ))}
        </div>
      </div>

      {/* Sección para seleccionar asset */}    
      <div className="form-group">
        <label>Asset:</label>
        <select value={assetId} onChange={e => setAssetId(parseInt(e.target.value))}>
          <option value="">Seleccione un asset</option>
          {assets.map(asset => (
            <option key={asset.id} value={asset.id}>{asset.name}</option>
          ))}
        </select>
      </div>

      {/* Sección para seleccionar fechas */}
      <div className="form-group">
        <label>Inicio:</label>
        <input
          type="datetime-local"
          value={formatLocalDateToInput(start)} // Mostrar la hora local
          onChange={e => {
            setStart(new Date(e.target.value)); // Crear Date objeto como hora local
          }}
        />
      </div>

      <div className="form-group">
        <label>Fin:</label>
        <input
          type="datetime-local"
          value={formatLocalDateToInput(end)} // Mostrar la hora local
          onChange={e => {
            setEnd(new Date(e.target.value)); // Crear Date objeto como hora local
          }}
        />
      </div>

      {/* Botón de programar */}
      <div className="form-group">
        <button className="programar-button" onClick={enviarProgramacion}>
          Programar
        </button>
      </div>

      {/* Modal de edición */}
      {showEditModal && (
        <div className="modal">
          <div className="modal-content">
            <h2>Editar Programación</h2>
            <p>Editando programación ID: {editandoProgramacion?.id}</p>

            <div className="form-group">
              <label>Asset:</label>
              <select value={assetId} onChange={e => setAssetId(parseInt(e.target.value))}> {/* Convertir a entero aquí */}
                <option value="">Seleccione un asset</option>
        {assets.map(asset => (
          <option key={asset.id} value={asset.id}>
            {asset.name}
          </option>
        ))}
      </select>
            </div>

            <div className="form-group">
              <label>Pantalla:</label>
              <select
                value={pantallaIds[0] || ''}
                onChange={e => setPantallaIds([parseInt(e.target.value)])}
              >
                <option value="">Seleccione una pantalla</option>
                {pantallas.map(pantalla => (
                  <option key={pantalla.id} value={pantalla.id}>
                    {pantalla.nombre}
                  </option>
                ))}
              </select>
            </div>

            <div className="form-group">
              <label>Inicio:</label>
              <input
                type="datetime-local"
                value={formatLocalDateToInput(start)}
                onChange={e => setStart(new Date(e.target.value))}
              />
            </div>

            <div className="form-group">
              <label>Fin:</label>
              <input
                type="datetime-local"
                value={formatLocalDateToInput(end)}
                onChange={e => setEnd(new Date(e.target.value))}
              />
            </div>

            <div className="modal-actions">
              <button onClick={actualizarProgramacion}>Actualizar</button>
              <button onClick={cancelarEdicion}>Cancelar</button>
            </div>
          </div>
        </div>
      )}

      {/* Tabla de programaciones */}
      <div className="programaciones-list">
        <h3>Programaciones existentes</h3>
        {programaciones && programaciones.length > 0 ? (
          <table>
            <thead>
              <tr>
                <th>ID</th>
                <th>Asset</th>
                <th>Pantalla</th>
                <th>Inicio</th>
                <th>Fin</th>
                <th>Estado</th>
                <th>Acciones</th>
              </tr>
            </thead>
            <tbody>
              {programaciones.map(prog => {
                // prog.start_date y prog.end_date son ahora objetos Date (UTC) desde el backend
                const assetName = prog.asset_name || assets.find(a => a.id === prog.asset_id)?.name || 'Asset no encontrado';
                const pantallaName = prog.pantalla_nombre || pantallas.find(p => p.id === prog.pantalla_id)?.nombre || 'Pantalla no encontrada';

                // Función para formatear un objeto Date (UTC) para mostrar en la zona horaria local
                const formatDateTimeForDisplay = (dateObj) => {
                  if (!dateObj) return '';
                  // Usar métodos de tiempo local para mostrar en la zona horaria del usuario
                  const year = dateObj.getFullYear();
                  const month = (dateObj.getMonth() + 1).toString().padStart(2, '0');
                  const day = dateObj.getDate().toString().padStart(2, '0');
                  const hours = dateObj.getHours().toString().padStart(2, '0');
                  const minutes = dateObj.getMinutes().toString().padStart(2, '0');
                  return `${year}-${month}-${day} ${hours}:${minutes}`;
                };

                return (
                  <tr key={prog.id}>
                    <td>{prog.id}</td>
                    <td>{assetName}</td>
                    <td>{pantallaName}</td>
                    <td>{formatDateTimeForDisplay(prog.start_date)}</td>
                    <td>{formatDateTimeForDisplay(prog.end_date)}</td>
                    <td>
                      <span className={`estado-badge ${prog.estado}`}>
                        {prog.estado}
                      </span>
                    </td>
                    <td>
                      <button onClick={() => cargarProgramacionParaEditar(prog)}>Editar</button>
                      <button onClick={() => eliminarProgramacion(prog.id)}>Eliminar</button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        ) : (
          <p>No hay programaciones creadas</p>
        )}
      </div>
    </div>
  );
};

export default ProgramarAsset;

