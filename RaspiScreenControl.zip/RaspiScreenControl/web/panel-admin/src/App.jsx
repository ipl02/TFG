//Componente principal de la aplicación 
import React, { useState, useEffect } from 'react';
import axios from 'axios'; // Importar axios
import ListaPantallas from './componentes/ListaPantallas';
import ListaAssets from './componentes/ListaAssets';
import ListaProgramaciones from './componentes/ListaProgramaciones';
import ProgramarAsset from './componentes/ProgramarAsset';
import Login from './componentes/login';
import Dashboard from './componentes/Dashboard';
import GestionarCuenta from './componentes/GestionarCuenta';
import './App.css';

const API_URL = 'http://localhost:3000/api';

function App() {
  const [usuario, setUsuario] = useState(null);
  const [vista, setVista] = useState('inicio');
  const [menuAbierto, setMenuAbierto] = useState(true);

  const menuItems = [
    { key: 'inicio', label: 'Inicio' },
    { key: 'programar', label: 'Programar Asset' },
    { key: 'assets', label: 'Assets' },
    { key: 'pantallas', label: 'Pantallas' },
    { key: 'perfil', label: 'Gestionar Cuenta' },
  ];

  useEffect(() => {
    const token = localStorage.getItem('token');
    if (token) {
      axios.defaults.headers.common['Authorization'] = `Bearer ${token}`;
      verificarToken();
    }
  }, []);

  const verificarToken = async () => {
    try {
      const response = await axios.get(`${API_URL}/usuarios/perfil`);
      setUsuario(response.data.usuario);
    } catch (error) {
      console.error('Error al verificar token:', error);
      localStorage.removeItem('token');
      delete axios.defaults.headers.common['Authorization'];
      setUsuario(null);
    }
  };

  const handleLogout = () => {
    localStorage.removeItem('token');
    delete axios.defaults.headers.common['Authorization'];
    setUsuario(null);
  };

  if (!usuario) {
    return <Login onLogin={setUsuario} />;
  }

  return (
    <div className="app">
      {/* Menú lateral */}
      <nav className={`menu ${menuAbierto ? 'menu-abierto' : 'menu-cerrado'}`}>
        {menuItems.map(item => (
          <button
            key={item.key}
            className={vista === item.key ? 'active' : ''}
            onClick={() => setVista(item.key)}
          >
            {item.label}
          </button>
        ))}
        <button onClick={handleLogout} style={{ marginTop: 'auto', background: '#8dad8f', color: '#406042' }}>Cerrar sesión</button>
      </nav>
      
      {/* Botón para alternar el menú, ahora después del nav */}
      <button className="menu-toggle-button" onClick={() => setMenuAbierto(!menuAbierto)}>
        ☰
      </button>

      {/* Contenido según la vista */}
      <main className={`contenido ${menuAbierto ? 'contenido-con-menu' : 'contenido-sin-menu'}`}>
        {vista === 'inicio' && (
          <Dashboard />
        )}
        {vista === 'programar' && <ProgramarAsset userId={usuario?.id} />}
        {vista === 'assets' && <ListaAssets />}
        {vista === 'pantallas' && <ListaPantallas />}
        {vista === 'perfil' && <GestionarCuenta />}
      </main>
    </div>
  );
}

export default App;
