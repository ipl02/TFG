const jwt = require('jsonwebtoken');

function verificarToken(req, res, next) {
  console.log('Middleware verificarToken: Iniciando verificación');
  console.log('Headers recibidos:', req.headers);
  
  const authHeader = req.headers['authorization'];
  console.log('Auth header:', authHeader);
  
  const token = authHeader && authHeader.split(' ')[1];
  console.log('Token extraído:', token ? 'Token presente' : 'No hay token');
  
  if (!token) {
    console.log('Middleware verificarToken: Token no encontrado');
    return res.status(401).json({ error: 'Token requerido' });
  }

  jwt.verify(token, process.env.JWT_SECRET, (err, user) => {
    if (err) {
      console.log('Middleware verificarToken: Error al verificar token:', err.message);
      return res.status(403).json({ error: 'Token inválido' });
    }
    console.log('Middleware verificarToken: Token válido, usuario:', user);
    req.user = user;
    next();
  });
}

function soloAdmin(req, res, next) {
  console.log('Middleware soloAdmin: Verificando rol:', req.user.rol);
  if (req.user.rol !== 'administrador') {
    console.log('Middleware soloAdmin: Acceso denegado - Rol incorrecto');
    return res.status(403).json({ error: 'Acceso solo para administradores' });
  }
  console.log('Middleware soloAdmin: Acceso permitido');
  next();
}

module.exports = { verificarToken, soloAdmin };
