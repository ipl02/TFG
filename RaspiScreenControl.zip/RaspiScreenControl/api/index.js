//Configuración del servidor Express
const express = require('express');
const cors = require('cors');
const path = require('path');
require('dotenv').config();

const app = express();

// Configuración de CORS específica para desarrollo
const corsOptions = {
  origin: ['http://localhost:5173', 'http://localhost:3000', 'http://10.0.2.2:3000'], 
  methods: 'GET,HEAD,PUT,PATCH,POST,DELETE',
  allowedHeaders: ['Content-Type', 'Authorization'],
  exposedHeaders: ['Content-Type', 'Authorization'],
  credentials: true,
  optionsSuccessStatus: 204
};

app.use(cors(corsOptions));
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ limit: '50mb', extended: true }));

// Servir archivos estáticos desde la carpeta simuladores
app.use('/simuladores', express.static(path.join(__dirname, '..', 'simuladores')));

// Rutas
const usuariosRutas = require('./rutas/usuarios');
const pantallasRutas = require('./rutas/pantallas');
const programacionRutas = require('./rutas/programacion');
const assetsRutas = require('./rutas/assets');
const authRutas = require('./rutas/auth');

// Aplicación de rutas base
app.use('/api/auth', authRutas); // login
app.use('/api/usuarios', usuariosRutas); // gestión de usuarios
app.use('/api/pantallas', pantallasRutas);
app.use('/api/programacion', programacionRutas);
app.use('/api/assets', assetsRutas);

// Puerto
const PORT = process.env.PORT || 3000;
// Forzamos que escuche en 0.0.0.0 (todas las interfaces) para la app android
app.listen(PORT, '0.0.0.0', () => {
  console.log(`Servidor escuchando en 0.0.0.0:${PORT}`);
});


    