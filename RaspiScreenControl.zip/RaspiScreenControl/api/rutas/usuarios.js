const express = require('express');
const router = express.Router();
const { verificarToken, soloAdmin } = require('../middleware/authMiddleware');
const bcrypt = require('bcrypt');
const db = require('../db');

// Ruta protegida: cualquier usuario autenticado
router.get('/perfil', verificarToken, (req, res) => {
  res.json({
    mensaje: 'Accediste al perfil',
    usuario: req.user,
  });
});

// Obtener todos los usuarios (solo admin)
router.get('/', verificarToken, soloAdmin, async (req, res) => {
  try {
    const [usuarios] = await db.query('SELECT id, usuario, nombre, apellidos, rol, fecha_creacion, ultimo_acceso FROM usuario');
    res.json({ usuarios });
  } catch (error) {
    console.error('Error al obtener usuarios:', error);
    res.status(500).json({ error: 'Error al obtener la lista de usuarios' });
  }
});

// Obtener un usuario específico (solo admin)
router.get('/:id', verificarToken, soloAdmin, async (req, res) => {
  try {
    const [usuarios] = await db.query(
      'SELECT id, usuario, nombre, apellidos, rol, fecha_creacion, ultimo_acceso FROM usuario WHERE id = ?',
      [req.params.id]
    );
    
    if (usuarios.length === 0) {
      return res.status(404).json({ error: 'Usuario no encontrado' });
    }
    
    res.json({ usuario: usuarios[0] });
  } catch (error) {
    console.error('Error al obtener usuario:', error);
    res.status(500).json({ error: 'Error al obtener el usuario' });
  }
});

// Crear nuevo usuario (solo admin)
router.post('/', verificarToken, soloAdmin, async (req, res) => {
  try {
    const { usuario, nombre, apellidos, clave, rol } = req.body;

    // Validar campos requeridos
    if (!usuario || !clave) {
      return res.status(400).json({ error: 'Usuario y contraseña son requeridos' });
    }

    // Verificar si el usuario ya existe
    const [existentes] = await db.query('SELECT id FROM usuario WHERE usuario = ?', [usuario]);
    if (existentes.length > 0) {
      return res.status(400).json({ error: 'El usuario ya existe' });
    }

    // Encriptar contraseña
    const salt = await bcrypt.genSalt(10);
    const claveEncriptada = await bcrypt.hash(clave, salt);

    // Insertar nuevo usuario
    const [resultado] = await db.query(
      'INSERT INTO usuario (usuario, nombre, apellidos, clave, rol) VALUES (?, ?, ?, ?, ?)',
      [usuario, nombre, apellidos, claveEncriptada, rol || 'usuario']
    );

    res.status(201).json({
      mensaje: 'Usuario creado correctamente',
      id: resultado.insertId
    });
  } catch (error) {
    console.error('Error al crear usuario:', error);
    res.status(500).json({ error: 'Error al crear el usuario' });
  }
});

// Actualizar usuario (solo admin)
router.put('/:id', verificarToken, soloAdmin, async (req, res) => {
  try {
    const { nombre, apellidos, clave, rol } = req.body;
    const userId = req.params.id;

    // Verificar si el usuario existe
    const [usuarios] = await db.query('SELECT id FROM usuario WHERE id = ?', [userId]);
    if (usuarios.length === 0) {
      return res.status(404).json({ error: 'Usuario no encontrado' });
    }

    // Preparar campos a actualizar
    let campos = [];
    let valores = [];

    if (nombre !== undefined) {
      campos.push('nombre = ?');
      valores.push(nombre);
    }
    if (apellidos !== undefined) {
      campos.push('apellidos = ?');
      valores.push(apellidos);
    }
    if (rol !== undefined) {
      campos.push('rol = ?');
      valores.push(rol);
    }
    if (clave) {
      const salt = await bcrypt.genSalt(10);
      const claveEncriptada = await bcrypt.hash(clave, salt);
      campos.push('clave = ?');
      valores.push(claveEncriptada);
    }

    if (campos.length === 0) {
      return res.status(400).json({ error: 'No hay campos para actualizar' });
    }

    // Actualizar usuario
    await db.query(
      `UPDATE usuario SET ${campos.join(', ')} WHERE id = ?`,
      [...valores, userId]
    );

    res.json({ mensaje: 'Usuario actualizado correctamente' });
  } catch (error) {
    console.error('Error al actualizar usuario:', error);
    res.status(500).json({ error: 'Error al actualizar el usuario' });
  }
});

// Eliminar usuario (solo admin)
router.delete('/:id', verificarToken, soloAdmin, async (req, res) => {
  try {
    const userId = req.params.id;

    // Verificar si el usuario existe
    const [usuarios] = await db.query('SELECT id FROM usuario WHERE id = ?', [userId]);
    if (usuarios.length === 0) {
      return res.status(404).json({ error: 'Usuario no encontrado' });
    }

    // No permitir eliminar el último administrador
    if (userId === req.user.id) {
      const [admins] = await db.query(
        'SELECT COUNT(*) as total FROM usuario WHERE rol = "administrador"'
      );
      if (admins[0].total <= 1) {
        return res.status(400).json({ 
          error: 'No se puede eliminar el último administrador del sistema' 
        });
      }
    }

    // Eliminar usuario
    await db.query('DELETE FROM usuario WHERE id = ?', [userId]);
    res.json({ mensaje: 'Usuario eliminado correctamente' });
  } catch (error) {
    console.error('Error al eliminar usuario:', error);
    res.status(500).json({ error: 'Error al eliminar el usuario' });
  }
});

module.exports = router;
