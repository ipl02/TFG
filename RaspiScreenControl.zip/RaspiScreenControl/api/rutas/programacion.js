//Configuración de las rutas de programacion
const express = require('express'); // Importa el framework Express
const router = express.Router(); // Crea un enrutador
const db = require('../db'); // Importa la conexión a la base de datos
const axios = require('axios'); // Importa la librería axios para hacer solicitudes HTTP
const { verificarToken } = require('../middleware/authMiddleware');

// GET programaciones
router.get('/', verificarToken, async (req, res) => {
    const query = `
      SELECT 
        p.id,
        p.pantalla_id,
        p.asset_id,
        pantalla.nombre AS pantalla_nombre,
        asset.name AS asset_nombre,
        p.start_date,
        p.end_date,
        p.play_order,
        p.is_enabled,
        p.estado
      FROM programacion p
      JOIN pantalla ON p.pantalla_id = pantalla.id
      JOIN asset ON p.asset_id = asset.id
      ORDER BY p.id DESC
    `;
    try {
      const [results] = await db.query(query);
      console.log('GET /programacion - Resultados raw de MySQL:', JSON.stringify(results, null, 2));
      
      // Devolver las fechas tal como están en la base de datos (ya en formato local)
      res.json(results);
    } catch (err) {
      console.error('Error al obtener la programación:', err);
      res.status(500).json({ error: 'Error en el servidor' });
    }
});
  
// POST programar asset en una pantalla
router.post('/', verificarToken, async(req, res) => {
  console.log('POST /programacion - Iniciando creación de programación');
  console.log('Datos recibidos:', JSON.stringify(req.body, null, 2));

  const {
    pantalla_ids,
    asset_id,
    is_enabled = 1,
    play_order = 1,
    start_date,
    end_date,
    created_by,
    estado = 'activo'
  } = req.body;

  // Validación de campos
  if (!pantalla_ids || !asset_id || !start_date || !end_date || !created_by) {
    console.log('POST /programacion - Faltan campos obligatorios:', {
      pantalla_ids: !!pantalla_ids,
      asset_id: !!asset_id,
      start_date: !!start_date,
      end_date: !!end_date,
      created_by: !!created_by
    });
    return res.status(400).json({ error: 'Faltan campos obligatorios' });
  }

  try {
    // Convertir las fechas a objetos Date
    const startDate = new Date(start_date);
    const endDate = new Date(end_date);

    if (isNaN(startDate.getTime()) || isNaN(endDate.getTime())) {
      console.error('POST /programacion - Fechas inválidas:', {
        start_date,
        end_date
      });
      return res.status(400).json({ error: 'Fechas inválidas' });
    }

    // Validar que la fecha de inicio sea anterior a la fecha de fin
    if (startDate >= endDate) {
      console.error('POST /programacion - Fecha de inicio posterior a fecha de fin:', {
        startDate: startDate.toLocaleString(),
        endDate: endDate.toLocaleString()
      });
      return res.status(400).json({ error: 'La fecha de inicio debe ser anterior a la fecha de fin' });
    }

    // Formatear las fechas en formato MySQL (YYYY-MM-DD HH:mm:ss)
    const formatDate = (date) => {
      const year = date.getFullYear();
      const month = String(date.getMonth() + 1).padStart(2, '0');
      const day = String(date.getDate()).padStart(2, '0');
      const hours = String(date.getHours()).padStart(2, '0');
      const minutes = String(date.getMinutes()).padStart(2, '0');
      const seconds = String(date.getSeconds()).padStart(2, '0');
      
      // Formato MySQL: YYYY-MM-DD HH:mm:ss
      return `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;
    };

    const startDateLocal = formatDate(startDate);
    const endDateLocal = formatDate(endDate);

    console.log('POST /programacion - Fechas formateadas:', {
      original_start: start_date,
      original_end: end_date,
      start_date_local: startDateLocal,
      end_date_local: endDateLocal,
      hora_inicio: startDate.getHours(),
      hora_fin: endDate.getHours()
    });

    const insertQuery = `
      INSERT INTO programacion 
      (pantalla_id, asset_id, is_enabled, play_order, start_date, end_date, created_by, estado) 
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `;

    const successes = [];
    const errors = [];

    // Procesar cada pantalla
    for (const pantalla_id of pantalla_ids) {
      try {
        console.log(`POST /programacion - Procesando pantalla ${pantalla_id}`);
        
        const values = [
          pantalla_id,
          asset_id,
          is_enabled,
          play_order,
          startDateLocal,
          endDateLocal,
          created_by,
          estado
        ];

        console.log('POST /programacion - Valores a insertar:', {
          pantalla_id,
          asset_id,
          start_date: values[4],
          end_date: values[5]
        });
        
        const [insertResult] = await db.query(insertQuery, values);

        // Verificar que las fechas se guardaron correctamente
        const [verifyResult] = await db.query(
          'SELECT start_date, end_date FROM programacion WHERE id = ?',
          [insertResult.insertId]
        );

        console.log('POST /programacion - Verificación de fechas guardadas:', {
          id: insertResult.insertId,
          fechas_guardadas: verifyResult[0]
        });

        console.log(`POST /programacion - Programación guardada para pantalla ${pantalla_id}:`, {
          insertId: insertResult.insertId,
          affectedRows: insertResult.affectedRows
        });

        successes.push({ 
          pantalla_id: pantalla_id, 
          message: 'Programación guardada correctamente'
        });
        
      } catch (err) {
        console.error(`POST /programacion - Error procesando pantalla ${pantalla_id}:`, err);
        errors.push({ 
          pantalla_id: pantalla_id, 
          error: err.message || 'Error desconocido'
        });
      }
    }

    console.log('POST /programacion - Proceso completado. Éxitos:', successes.length, 'Errores:', errors.length);
    res.status(errors.length > 0 ? 207 : 201).json({
      message: 'Programación procesada',
      success: successes,
      errors: errors
    });
  } catch (err) {
    console.error('POST /programacion - Error general:', err);
    res.status(500).json({ error: 'Error interno del servidor' });
  }
});

// GET Assets activos de una pantalla
router.get('/:pantallaId/activa', verificarToken, (req, res) => {
  const { pantallaId } = req.params;
  const now = new Date()

  const query = `
    SELECT p.id as programacion_id, a.*
    FROM programacion p
    JOIN asset a ON p.asset_id = a.id
    WHERE p.pantalla_id = ? 
      AND p.is_enabled = 1
      AND p.start_date <= ?
      AND p.end_date >= ?
      AND p.estado = 'activo'
    ORDER BY p.play_order ASC
  `;

  //Ejecuta la consulta
  db.query(query, [pantallaId, now, now], (err, filas) => {
    if (err) {
      console.error('Error al obtener programación activa:', err);
      return res.status(500).json({ error: 'Error del servidor' });
    }

    res.json(filas);
  });
});

// PUT actualizar una programación existente
router.put('/:id', verificarToken, async (req, res) => {
    const programacionId = req.params.id;
    const { 
        pantalla_id, 
        asset_id, 
        start_date, 
        end_date, 
        play_order, 
        is_enabled, 
        estado 
    } = req.body;

    console.log('PUT /programacion/:id - Actualizando programación:', {
        id: programacionId,
        datos: req.body
    });

    try {
        // Verificar que la programación existe
        const [existing] = await db.query('SELECT * FROM programacion WHERE id = ?', [programacionId]);

        if (existing.length === 0) {
            console.log('Programación no encontrada:', programacionId);
            return res.status(404).json({ error: 'Programación no encontrada' });
        }

        // Las fechas ya vienen como ISO strings (UTC) del frontend
        // Convertir a objetos Date solo para validación si es necesario, pero pasar ISO directamente al query
        const updateStartDate = new Date(start_date);
        const updateEndDate = new Date(end_date);

        if (isNaN(updateStartDate.getTime()) || isNaN(updateEndDate.getTime())) {
            return res.status(400).json({ error: 'Fechas inválidas para actualización' });
        }

        // Actualizar la programación
        const [result] = await db.query(`
            UPDATE programacion 
            SET pantalla_id = ?,
                asset_id = ?,
                start_date = ?,
                end_date = ?,
                play_order = ?,
                is_enabled = ?,
                estado = ?,
                updated_at = CURRENT_TIMESTAMP
            WHERE id = ?
        `, [
            pantalla_id,
            asset_id,
            start_date, // Pasa el ISO string completo (UTC) directamente
            end_date,   // Pasa el ISO string completo (UTC) directamente
            play_order || 0,
            is_enabled,
            estado,
            programacionId
        ]);

        if (result.affectedRows === 0) {
            console.log('No se pudo actualizar la programación:', programacionId);
            return res.status(400).json({ error: 'No se pudo actualizar la programación' });
        }

        console.log('Programación actualizada exitosamente:', programacionId);
        res.json({ 
            mensaje: 'Programación actualizada exitosamente',
            id: programacionId
        });

    } catch (err) {
        console.error('Error al actualizar programación:', err);
        res.status(500).json({ error: 'Error interno del servidor' });
    }
});

// DELETE una programación por ID
router.delete('/:id', verificarToken, async (req, res) => {
  console.log('DELETE /programacion/:id - Iniciando eliminación');
  console.log('ID a eliminar:', req.params.id);
  console.log('Usuario autenticado:', req.user);
  
  const { id } = req.params;

  try {
    // Primero verificamos si la programación existe
    console.log('Verificando existencia de la programación...');
    const [checkResult] = await db.query('SELECT id FROM programacion WHERE id = ?', [id]);
    
    if (checkResult.length === 0) {
      console.log('Programación no encontrada con ID:', id);
      return res.status(404).json({ error: 'Programación no encontrada' });
    }

    console.log('Programación encontrada, procediendo a eliminar...');
    
    // Intentamos eliminar
    const [deleteResult] = await db.query('DELETE FROM programacion WHERE id = ?', [id]);
    
    console.log('Resultado de la eliminación:', deleteResult);
    
    if (deleteResult.affectedRows === 0) {
      console.log('No se pudo eliminar la programación con ID:', id);
      return res.status(500).json({ error: 'No se pudo eliminar la programación' });
    }

    console.log('Programación eliminada exitosamente');
    res.json({ message: 'Programación eliminada correctamente' });
    
  } catch (error) {
    console.error('Error en la operación DELETE:', error);
    // Enviamos un error más específico
    res.status(500).json({ 
      error: 'Error al eliminar la programación',
      details: error.message,
      code: error.code
    });
  }
});

router.get('/pantallas/:pantalla_id/programacion-activa', verificarToken, async (req, res) => {
  const { pantalla_id } = req.params;
  
  // Obtener la hora actual en la zona horaria local
  const ahora = new Date();
  
  // Formatear la hora actual en formato MySQL (YYYY-MM-DD HH:mm:ss)
  const formatDate = (date) => {
    // Usar los métodos locales para asegurar que obtenemos la hora local
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    const hours = String(date.getHours()).padStart(2, '0');  // getHours() devuelve la hora local
    const minutes = String(date.getMinutes()).padStart(2, '0');
    const seconds = String(date.getSeconds()).padStart(2, '0');
    
    const fechaFormateada = `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;
    
    // Log para depuración
    console.log('Formateando fecha:', {
      fecha_original: date.toISOString(),
      fecha_local: date.toLocaleString(),
      fecha_formateada: fechaFormateada,
      hora_local: date.getHours(),
      hora_utc: date.getUTCHours()
    });
    
    return fechaFormateada;
  };

  // Usar directamente la fecha actual, ya que getHours() devuelve la hora local
  const hora_actual_local = formatDate(ahora);

  console.log('GET /pantallas/${pantalla_id}/programacion-activa - Fechas:', {
    hora_actual: {
      utc: ahora.toISOString(),
      local: ahora.toLocaleString(),
      formatted_for_mysql: hora_actual_local,
      hora_local: ahora.getHours(),
      hora_utc: ahora.getUTCHours()
    }
  });

  // Modificar la consulta para usar la hora local
  const query = `
    SELECT 
      p.id,
      p.pantalla_id,
      p.asset_id,
      a.name AS asset_nombre,
      a.type AS asset_type,
      a.url AS asset_url,
      a.duration AS asset_duration,
      p.start_date,
      p.end_date,
      p.play_order,
      p.is_enabled,
      p.estado
    FROM programacion p
    JOIN asset a ON p.asset_id = a.id
    WHERE p.pantalla_id = ?
    AND p.is_enabled = 1
    AND p.estado = 'activo'
    AND ? BETWEEN p.start_date AND p.end_date
    ORDER BY p.play_order ASC
  `;

  try {
    // Verificar las fechas en la base de datos antes de la consulta
    const [fechasDB] = await db.query(
      'SELECT id, start_date, end_date, HOUR(start_date) as hora_inicio, HOUR(end_date) as hora_fin FROM programacion WHERE pantalla_id = ? AND is_enabled = 1 AND estado = "activo"',
      [pantalla_id]
    );

    console.log('Fechas en la base de datos:', fechasDB.map(f => ({
      id: f.id,
      start_date: f.start_date,
      end_date: f.end_date,
      hora_inicio: f.hora_inicio,
      hora_fin: f.hora_fin
    })));

    const [results] = await db.query(query, [pantalla_id, hora_actual_local]);

    // Verificar las fechas de las programaciones encontradas
    const programacionesConHoras = results.map(p => {
      const startDate = new Date(p.start_date);
      const endDate = new Date(p.end_date);
      return {
        ...p,
        hora_inicio_local: startDate.getHours(),
        hora_fin_local: endDate.getHours(),
        hora_inicio_utc: startDate.getUTCHours(),
        hora_fin_utc: endDate.getUTCHours(),
        start_date_local: startDate.toLocaleString(),
        end_date_local: endDate.toLocaleString()
      };
    });

    console.log('GET /pantallas/${pantalla_id}/programacion-activa - Resultados:', {
      pantalla_id,
      hora_actual_local,
      hora_actual_utc: ahora.toISOString(),
      hora_local_numero: ahora.getHours(),
      programaciones_encontradas: results.length,
      programaciones: programacionesConHoras.map(p => ({
        id: p.id,
        start_date: p.start_date,
        end_date: p.end_date,
        start_date_local: p.start_date_local,
        end_date_local: p.end_date_local,
        asset_nombre: p.asset_nombre,
        hora_inicio_local: p.hora_inicio_local,
        hora_fin_local: p.hora_fin_local,
        hora_inicio_utc: p.hora_inicio_utc,
        hora_fin_utc: p.hora_fin_utc
      }))
    });

    if (results.length === 0) {
      // Asegurarnos de que la respuesta de error también use la hora local
      const errorResponse = {
        message: 'No hay programación activa para esta pantalla',
        hora_actual: hora_actual_local,
        hora_local: ahora.getHours(),
        hora_utc: ahora.getUTCHours(),
        hora_local_formatted: ahora.toLocaleString()
      };
      console.log('No hay programación activa para la pantalla:', pantalla_id, errorResponse);
      return res.status(404).json(errorResponse);
    }

    // Devolver las fechas tal como están en la base de datos
    res.json(results);
  } catch (err) {
    console.error('Error al obtener la programación activa:', err);
    res.status(500).json({ 
      error: 'Error en el servidor',
      hora_actual: hora_actual_local,
      hora_local: ahora.getHours(),
      hora_local_formatted: ahora.toLocaleString()
    });
  }
});

module.exports = router;