//Configuración de las rutas de assets
const express = require('express'); // Importa el framework Express
const router = express.Router(); // Crea un enrutador
const db = require('../db'); // Importa la conexión a la base de datos
const { verificarToken } = require('../middleware/authMiddleware');

// GET assets
router.get('/', verificarToken, async (req, res) => {
    const query = `
      SELECT 
        id,
        name,
        mimetype,
        uri,
        duration,
        start_date,
        end_date,
        is_active,
        is_enabled,
        usuario_id
      FROM asset
    `;
    try {
      const [results] = await db.query(query);
      res.json(results);
    } catch (err) {
      console.error('Error al obtener los assets:', err);
      res.status(500).json({ error: 'Error en el servidor' });
    }
});

// POST assets
router.post('/', verificarToken, (req, res) => {
  const {
    name,
    uri,
    mimetype,
    duration,
    start_date,
    end_date,
    usuario_id
  } = req.body;

  if (!name || !uri || !mimetype) {
    return res.status(400).json({ error: 'Faltan campos obligatorios.' });
  }

  const query = `
    INSERT INTO asset (
      name,
      uri,
      mimetype,
      duration,
      start_date,
      end_date,
      is_active,
      usuario_id
    )
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
  `;

  db.query(
    query,
    [
      name,
      uri,
      mimetype,
      duration || null,
      start_date || new Date().toISOString().slice(0, 19).replace('T', ' '),
      end_date || null,
      1, // is_active por defecto
      usuario_id || 1
    ],
    (err, results) => {
      if (err) {
        console.error('Error al insertar asset:', err);
        return res.status(500).json({ error: 'Error al insertar asset.' });
      }
      res.json({ id: results.insertId });
    }
  );
});

// DELETE asset
router.delete('/:id', verificarToken, async (req, res) => {
  const { id } = req.params;

  try {
    // Primero verificar si el asset existe
    const [existing] = await db.query('SELECT id FROM asset WHERE id = ?', [id]);
    
    if (existing.length === 0) {
      return res.status(404).json({ error: 'Asset no encontrado' });
    }

    // Verificar si el asset está siendo usado en alguna programación
    const [programaciones] = await db.query(
      'SELECT id FROM programacion WHERE asset_id = ?',
      [id]
    );

    if (programaciones.length > 0) {
      return res.status(400).json({ 
        error: 'No se puede eliminar el asset porque está siendo usado en programaciones activas',
        programaciones: programaciones.length
      });
    }

    // Si no está siendo usado, proceder con la eliminación
    const query = `
      DELETE FROM asset
      WHERE id = ?
    `;

    await db.query(query, [id]);
    res.json({ message: 'Asset eliminado correctamente' });
  } catch (err) {
    console.error('Error al eliminar el asset:', err);
    res.status(500).json({ error: 'Error al eliminar el asset.' });
  }
});

// PUT actualizar asset
router.put('/:id', verificarToken, async (req, res) => {
  const { id } = req.params;
  const {
    name,
    uri,
    mimetype,
    duration,
    start_date,
    end_date,
    is_active
  } = req.body;

  try {
    // Verificar si el asset existe
    const [existing] = await db.query('SELECT id FROM asset WHERE id = ?', [id]);
    
    if (existing.length === 0) {
      return res.status(404).json({ error: 'Asset no encontrado' });
    }

    const query = `
      UPDATE asset
      SET name = ?,
          uri = ?,
          mimetype = ?,
          duration = ?,
          start_date = ?,
          end_date = ?,
          is_active = ?,
          updated_at = CURRENT_TIMESTAMP
      WHERE id = ?
    `;

    await db.query(query, [
      name,
      uri,
      mimetype,
      duration || null,
      start_date || null,
      end_date || null,
      is_active,
      id
    ]);

    res.json({ message: 'Asset actualizado correctamente' });
  } catch (err) {
    console.error('Error al actualizar el asset:', err);
    res.status(500).json({ error: 'Error al actualizar el asset.' });
  }
});

module.exports = router;