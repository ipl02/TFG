//Configuración de las rutas de pantallas
const express = require('express'); // Importa el framework Express
const router = express.Router(); // Crea un enrutador
const pool = require('../db'); // Usamos el pool de conexiones
const { verificarToken} = require('../middleware/authMiddleware');
require('dotenv').config();

// Configuración de la base de datos usando variables de entorno
const dbConfig = {
    host: process.env.DB_HOST || 'localhost',
    user: process.env.DB_USER || 'root',
    password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME || 'raspiscreencontrol'
};

// GET pantallas
router.get('/', verificarToken, async (req, res) => {
    try {
        const [rows] = await pool.execute('SELECT * FROM pantalla');
        res.json(rows);
    } catch (err) {
            console.error('Error al obtener pantallas:', err);
        res.status(500).json({ error: 'Error en el servidor' });
        }
});

// GET asset/programacion actual de una pantalla
router.get('/:id/programacion-activa', async (req, res) => {
    const { id: pantalla_id } = req.params;
    
    // Obtener la hora actual en la zona horaria local
    const ahora = new Date();
    
    // Formatear la hora actual en formato MySQL (YYYY-MM-DD HH:mm:ss)
    const formatDate = (date) => {
        const year = date.getFullYear();
        const month = String(date.getMonth() + 1).padStart(2, '0');
        const day = String(date.getDate()).padStart(2, '0');
        const hours = String(date.getHours()).padStart(2, '0');
        const minutes = String(date.getMinutes()).padStart(2, '0');
        const seconds = String(date.getSeconds()).padStart(2, '0');
        
        return `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;
    };

    const hora_actual_local = formatDate(ahora);

    console.log('GET /pantallas/${pantalla_id}/programacion-activa - Fechas:', {
        hora_actual: {
            utc: ahora.toISOString(),
            local: ahora.toLocaleString(),
            formatted_for_mysql: hora_actual_local,
            hora_local: ahora.getHours(),
            hora_utc: ahora.getUTCHours()
        }
    });

    try {
        // Primero obtenemos la programación actual usando la hora local
        const [rows] = await pool.execute(`
            SELECT p.*, a.* 
            FROM programacion p
            JOIN asset a ON p.asset_id = a.id
            WHERE p.pantalla_id = ? 
            AND p.is_enabled = 1
            AND p.estado = 'activo'
            AND p.start_date <= ?
            AND p.end_date >= ?
            ORDER BY p.play_order ASC, p.start_date DESC
        LIMIT 1
        `, [pantalla_id, hora_actual_local, hora_actual_local]);

        if (rows.length === 0) {
            console.log('No hay programación activa para la pantalla:', pantalla_id, {
                hora_actual: hora_actual_local,
                hora_local: ahora.getHours(),
                hora_utc: ahora.getUTCHours()
            });
            return res.status(404).json({ message: 'Sin contenido' });
        }

        const row = rows[0];
        
        // Convertir las fechas de la base de datos a objetos Date
        const startDate = new Date(row.start_date);
        const endDate = new Date(row.end_date);

        console.log('Programación activa encontrada:', {
            id: row.id,
            pantalla_id: pantalla_id,
            asset_name: row.name,
            fechas: {
                inicio: {
                    db: row.start_date,
                    local: startDate.toLocaleString()
                },
                fin: {
                    db: row.end_date,
                    local: endDate.toLocaleString()
                }
            },
            hora_actual: {
                local: hora_actual_local,
                hora_local: ahora.getHours(),
                hora_utc: ahora.getUTCHours()
            }
        });

        // Devolver el asset con la información necesaria
        res.json({
            asset: {
                id: row.asset_id,
                name: row.name,
                type: row.mimetype,
                url: row.uri,
                duration: row.duration
            }
        });

    } catch (error) {
        console.error('Error al obtener programación activa:', error);
        res.status(500).json({ error: 'Error del servidor' });
    }
});

// POST nueva pantalla
router.post('/', verificarToken, async (req, res) => {
    const { nombre, direccion_IP, estado, ubicacion } = req.body;
  
    if (!nombre || !direccion_IP) {
      return res.status(400).json({ error: 'Faltan campos obligatorios.' });
    }
  
    try {
        const [result] = await pool.execute(
            'INSERT INTO pantalla (nombre, direccion_IP, estado, ubicacion) VALUES (?, ?, ?, ?)',
            [nombre, direccion_IP, estado || 'activa', ubicacion || 'sin ubicación']
        );
        
        res.json({ id: result.insertId });
    } catch (err) {
        console.error('Error al insertar pantalla:', err);
        res.status(500).json({ error: 'Error al insertar pantalla.' });
    }
});

// DELETE pantalla
router.delete('/:id', verificarToken, async (req, res) => {
    const pantalla_id = req.params.id;
    try {
        await pool.execute('DELETE FROM pantalla WHERE id = ?', [pantalla_id]);
        res.json({ message: 'Pantalla eliminada correctamente' });
    } catch (err) {
        console.error('Error al eliminar pantalla:', err);
        res.status(500).json({ error: 'Error al eliminar pantalla.' });
    }
});

// PUT actualizar pantalla
router.put('/:id', verificarToken, async (req, res) => {
    const pantalla_id = req.params.id;
    const { nombre, direccion_IP, estado, ubicacion } = req.body;
  
    if (!nombre || !direccion_IP) {
        return res.status(400).json({ error: 'Faltan campos obligatorios.' });
    }
  
    try {
        await pool.execute(`
            UPDATE pantalla
            SET nombre = ?,
                direccion_IP = ?,
                estado = ?,
                ubicacion = ?
            WHERE id = ?
        `, [nombre, direccion_IP, estado || 'activa', ubicacion || 'sin ubicación', pantalla_id]);
        
        res.json({ message: 'Pantalla actualizada correctamente' });
    } catch (err) {
        console.error('Error al actualizar pantalla:', err);
        res.status(500).json({ error: 'Error al actualizar pantalla.' });
    }
});

// Cerrar la conexión a la base de datos cuando se cierra la aplicación
process.on('SIGINT', () => {
    pool.end((err) => {
        if (err) {
            console.error('Error al cerrar la base de datos:', err);
        } else {
            console.log('Conexión a la base de datos cerrada');
        }
        process.exit(0);
    });
  });
  
module.exports = router;