const express = require('express');
const router = express.Router();
const jwt = require('jsonwebtoken');
const bcrypt = require('bcrypt');
const pool = require('../db');

// POST /api/auth/login
router.post('/login', async (req, res) => {
  const { usuario, clave } = req.body;
  
  try {
    const [rows] = await pool.query('SELECT * FROM usuario WHERE usuario = ?', [usuario]);
    if (rows.length === 0) return res.status(401).json({ error: 'Usuario o clave incorrectos' });

    const user = rows[0];
    if (!await bcrypt.compare(clave, user.clave)) return res.status(401).json({ error: 'Usuario o clave incorrectos' });

    // Si la clave es correcta, genera el token
    const token = jwt.sign(
      { id: user.id, usuario: user.usuario, rol: user.rol },
      process.env.JWT_SECRET,
      { expiresIn: '24h' }
    );
    res.json({ token, user: { id: user.id, usuario: user.usuario, rol: user.rol } });
  } catch (err) {
    console.error('Error en login:', err);
    res.status(500).json({ error: 'Error en el servidor' });
  }
});

module.exports = router;
