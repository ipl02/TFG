-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 13-06-2025 a las 13:17:50
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `raspiscreencontrol_db`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `asset`
--

CREATE TABLE `asset` (
  `id` int(11) NOT NULL,
  `is_enabled` int(11) NOT NULL DEFAULT 0,
  `mimetype` varchar(50) NOT NULL,
  `end_date` varchar(50) NOT NULL,
  `is_active` tinyint(4) DEFAULT 1,
  `duration` varchar(30) NOT NULL,
  `is_processing` int(11) NOT NULL DEFAULT 0,
  `asset_id` varchar(200) DEFAULT NULL,
  `name` varchar(100) NOT NULL,
  `nocache` int(11) NOT NULL DEFAULT 0,
  `uri` varchar(500) NOT NULL,
  `skip_asset_check` int(11) NOT NULL DEFAULT 0,
  `play_order` int(1) NOT NULL DEFAULT 0,
  `start_date` varchar(50) NOT NULL,
  `usuario_id` int(11) NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Volcado de datos para la tabla `asset`
--

INSERT INTO `asset` (`id`, `is_enabled`, `mimetype`, `end_date`, `is_active`, `duration`, `is_processing`, `asset_id`, `name`, `nocache`, `uri`, `skip_asset_check`, `play_order`, `start_date`, `usuario_id`, `updated_at`) VALUES
(2, 1, 'image/png', '2025-06-13T00:00:00+00:00', 1, '60', 0, NULL, 'Imagen iberovinac', 0, 'https://www.feval.com/wp-content/uploads/2025/03/IMAGEN-640x800.jpeg', 0, 0, '2025-03-31T00:00:00+00:00', 2, '2025-06-12 15:49:08'),
(3, 1, 'image/png', '2025-06-13T00:00:00+00:00', 1, '60', 0, NULL, 'Mapa feval', 0, 'https://www.feval.com/wp-content/uploads/2019/06/elrecinto-800x302.png', 0, 0, '2025-03-31T00:00:00+00:00', 2, '2025-06-12 15:49:08'),
(4, 1, 'image/png', '2025-06-13T00:00:00+00:00', 1, '90', 0, NULL, 'Exposicion pintura', 0, 'https://villanuevadelaserena.es/wp-content/uploads/2025/04/EXPOSICION-PINTURA-UNIV-MAYORES-768x1080.jpg', 0, 0, '2025-03-31T00:00:00+00:00', 2, '2025-06-12 15:49:08'),
(5, 1, 'image/png', '2025-06-13T00:00:00+00:00', 1, '90', 0, NULL, 'LaCarrerita', 0, 'https://villanuevadelaserena.es/wp-content/uploads/2025/04/DSC08534-Copiar-450x350.jpg', 0, 0, '2025-03-31T00:00:00+00:00', 2, '2025-06-12 15:49:08'),
(8, 0, 'image/jpeg', '2026-06-12 20:00:00', 1, '60', 0, NULL, 'imagen2', 0, 'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/4gHYSUNDX1BST0ZJTEUAAQEAAAHIAAAAAAQwAABtbnRyUkdCIFhZWiAH4AABAAEAAAAAAABhY3NwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAA9tYAAQAAAADTLQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlkZXNjAAAA8AAAACRyWFlaAAABFAAAABRnWFlaAAABKAAAABRiWFlaAAABPAAAABR3dHB0AAABUAAAABRyVFJDAAABZAAAAChnVFJDAAABZAAAAChiVFJDAAABZAAAAChjcHJ0AAABjAAAADxtbHVjAAAAAAAAAAEAAAAMZW5VUwAAAAgAAAAcAHMAUgBHAEJYWVogAAAAAAAAb6IAADj1AAADkFhZWiAAAAAAAABimQAAt4UAABjaWFlaI', 0, 0, '2025-06-12 13:33:23', 2, '2025-06-12 15:50:02'),
(29, 0, 'video/mp4', '2026-06-12 22:00:00', 1, '60', 0, NULL, 'video', 0, 'https://cdn.pixabay.com/video/2025/05/06/277097_large.mp4', 0, 0, '2025-06-13 10:06:54', 2, '2025-06-13 10:07:07');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `historial_actividad`
--

CREATE TABLE `historial_actividad` (
  `id` int(11) NOT NULL,
  `usuario_id` int(11) NOT NULL,
  `tipo_accion` enum('Crear','Actualizar','Eliminar','Inicio sesion','Cierre sesion') DEFAULT NULL,
  `descripcion` varchar(250) NOT NULL,
  `fecha_hora` timestamp NOT NULL DEFAULT current_timestamp(),
  `nombre_recurso_afectado` varchar(100) NOT NULL,
  `tipo_recurso` enum('pantalla','asset','programación','usuario') NOT NULL,
  `detalles` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`detalles`))
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pantalla`
--

CREATE TABLE `pantalla` (
  `id` int(11) NOT NULL,
  `nombre` varchar(30) NOT NULL,
  `direccion_IP` varchar(45) NOT NULL,
  `estado` enum('activa','inactiva') NOT NULL DEFAULT 'inactiva',
  `ubicacion` varchar(50) NOT NULL,
  `fecha_registro` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Volcado de datos para la tabla `pantalla`
--

INSERT INTO `pantalla` (`id`, `nombre`, `direccion_IP`, `estado`, `ubicacion`, `fecha_registro`) VALUES
(1, 'Pantalla prueba', '192.168.137.15', 'activa', 'Despacho', '2025-03-31 11:13:00'),
(2, 'Pantalla FEVAL', '192.168.20.225', 'activa', 'Entrada principal FEVAL', '2025-03-31 11:13:00'),
(3, 'Pantalla prueba 2', '192.168.1.206', 'activa', 'Despacho', '2025-04-22 09:30:41'),
(10, 'Pantalla app', '192.168.2.2', 'activa', 'android', '2025-06-13 01:02:23'),
(14, 'pantala prueba', '192.165.2.2', 'activa', 'cracovia', '2025-06-13 09:58:19');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `programacion`
--

CREATE TABLE `programacion` (
  `id` int(11) NOT NULL,
  `pantalla_id` int(11) NOT NULL,
  `asset_id` int(11) NOT NULL,
  `is_enabled` tinyint(4) DEFAULT 1,
  `play_order` int(11) NOT NULL DEFAULT 0,
  `start_date` varchar(50) NOT NULL,
  `end_date` varchar(50) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `created_by` int(11) NOT NULL,
  `estado` enum('pendiente','activo','finalizado','pausado') NOT NULL DEFAULT 'pendiente'
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Volcado de datos para la tabla `programacion`
--

INSERT INTO `programacion` (`id`, `pantalla_id`, `asset_id`, `is_enabled`, `play_order`, `start_date`, `end_date`, `created_at`, `updated_at`, `created_by`, `estado`) VALUES
(3, 1, 2, 0, 0, '2025-04-10T00:00:00+00:00', '2025-04-30T00:00:00+00:00', '2025-04-15 07:38:07', '2025-06-12 12:12:57', 1, 'activo'),
(52, 2, 3, 1, 0, '2025-06-11T02:46:00.000Z', '2025-06-11T03:46:00.000Z', '2025-06-11 02:46:34', '2025-06-11 02:46:34', 1, 'activo'),
(56, 1, 3, 1, 0, '2025-06-11T02:00:00.000Z', '2025-06-11T02:01:00.000Z', '2025-06-11 02:59:30', '2025-06-11 02:59:30', 1, 'activo'),
(65, 1, 3, 1, 0, '2025-06-11T17:49:00.000Z', '2025-06-11T17:51:00.000Z', '2025-06-11 17:49:26', '2025-06-11 17:49:26', 1, 'activo'),
(96, 1, 5, 1, 0, '2025-06-12 15:04:00', '2025-06-12 15:07:00', '2025-06-12 13:03:35', '2025-06-12 13:03:35', 2, 'activo'),
(97, 2, 4, 1, 0, '2025-06-12T13:05:00.000Z', '2025-06-12T13:07:00.000Z', '2025-06-12 13:04:16', '2025-06-12 13:13:37', 2, 'activo'),
(98, 1, 8, 1, 0, '2025-06-12T20:22:00.000Z', '2025-06-12T20:24:00.000Z', '2025-06-12 20:21:50', '2025-06-12 20:24:02', 2, 'activo'),
(99, 2, 3, 1, 0, '2025-06-12 22:23:00', '2025-06-12 22:25:00', '2025-06-12 20:22:36', '2025-06-12 20:22:36', 2, 'activo'),
(100, 1, 3, 1, 0, '2025-06-12 22:23:00', '2025-06-12 22:25:00', '2025-06-12 20:22:36', '2025-06-12 20:22:36', 2, 'activo'),
(104, 1, 5, 1, 0, '2025-06-13 12:05:00', '2025-06-13 12:06:00', '2025-06-13 10:03:46', '2025-06-13 10:03:46', 1, 'activo'),
(105, 2, 5, 1, 0, '2025-06-13 12:05:00', '2025-06-13 12:06:00', '2025-06-13 10:03:46', '2025-06-13 10:03:46', 1, 'activo'),
(106, 1, 29, 1, 0, '2025-06-13 12:08:00', '2025-06-13 12:10:00', '2025-06-13 10:07:37', '2025-06-13 10:07:37', 4, 'activo');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuario`
--

CREATE TABLE `usuario` (
  `id` int(11) NOT NULL,
  `usuario` varchar(30) NOT NULL,
  `clave` varchar(255) NOT NULL,
  `nombre` varchar(50) NOT NULL,
  `apellidos` varchar(50) NOT NULL,
  `rol` enum('usuario','administrador') NOT NULL DEFAULT 'usuario',
  `fecha_creacion` timestamp NOT NULL DEFAULT current_timestamp(),
  `ultimo_acceso` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Volcado de datos para la tabla `usuario`
--

INSERT INTO `usuario` (`id`, `usuario`, `clave`, `nombre`, `apellidos`, `rol`, `fecha_creacion`, `ultimo_acceso`) VALUES
(1, 'admin', '$2b$10$S7WtXn74HppxctMea5AGkudOo48pWvtxlnUOV.WxGCPSlxW9Na/4S', 'Administrador', 'FEVAL', 'administrador', '2025-03-31 11:13:00', NULL),
(2, 'isapl', '$2b$10$1jM5.9332rpIofczbUaYdOgbPkyO9cJAGXRcUyZ.qCMRgZgduD9mi', 'Isabel', 'Pineda', 'usuario', '2025-03-31 11:13:00', NULL),
(4, 'nuevo', '$2b$10$x2a/gv.UGsSpIIsWqZMq0OVy.Rucz9I7QYhoaUxeJ90D0f048qKvO', 'nuevo', 'user', 'usuario', '2025-06-13 10:04:41', NULL);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `asset`
--
ALTER TABLE `asset`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `asset_id` (`asset_id`),
  ADD UNIQUE KEY `asset_id_2` (`asset_id`),
  ADD UNIQUE KEY `asset_id_3` (`asset_id`),
  ADD UNIQUE KEY `asset_id_4` (`asset_id`),
  ADD UNIQUE KEY `asset_id_5` (`asset_id`),
  ADD KEY `usuario_id` (`usuario_id`);

--
-- Indices de la tabla `historial_actividad`
--
ALTER TABLE `historial_actividad`
  ADD PRIMARY KEY (`id`),
  ADD KEY `usuario_id` (`usuario_id`);

--
-- Indices de la tabla `pantalla`
--
ALTER TABLE `pantalla`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `programacion`
--
ALTER TABLE `programacion`
  ADD PRIMARY KEY (`id`),
  ADD KEY `pantalla_id` (`pantalla_id`),
  ADD KEY `asset_id` (`asset_id`),
  ADD KEY `created_by` (`created_by`);

--
-- Indices de la tabla `usuario`
--
ALTER TABLE `usuario`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `usuario` (`usuario`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `asset`
--
ALTER TABLE `asset`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT de la tabla `historial_actividad`
--
ALTER TABLE `historial_actividad`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `pantalla`
--
ALTER TABLE `pantalla`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT de la tabla `programacion`
--
ALTER TABLE `programacion`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=107;

--
-- AUTO_INCREMENT de la tabla `usuario`
--
ALTER TABLE `usuario`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `asset`
--
ALTER TABLE `asset`
  ADD CONSTRAINT `asset_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuario` (`id`) ON DELETE CASCADE;

--
-- Filtros para la tabla `historial_actividad`
--
ALTER TABLE `historial_actividad`
  ADD CONSTRAINT `historial_actividad_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuario` (`id`) ON DELETE CASCADE;

--
-- Filtros para la tabla `programacion`
--
ALTER TABLE `programacion`
  ADD CONSTRAINT `programacion_ibfk_1` FOREIGN KEY (`pantalla_id`) REFERENCES `pantalla` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `programacion_ibfk_2` FOREIGN KEY (`asset_id`) REFERENCES `asset` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `programacion_ibfk_3` FOREIGN KEY (`created_by`) REFERENCES `usuario` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
