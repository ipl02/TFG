# Panel de Control de Pantallas

Sistema de gestión y control de pantallas digitales.

## Requisitos

- Node.js (versión 14 o superior)
- MySQL (versión 8.0 o superior)
- npm (incluido con Node.js)

## Configuración

1. Clona el repositorio
2. Crea un archivo `.env` en la carpeta `api` con las siguientes variables:
   ```
   DB_HOST=localhost
   DB_USER=tu_usuario
   DB_PASSWORD=tu_contraseña
   DB_NAME=nombre_base_datos
   JWT_SECRET=tu_clave_secreta
   ```
3. Ejecuta el script SQL `api/database.sql` en tu servidor MySQL

## Ejecución

### Servidor Backend
1. Navega a la carpeta `api`:
   ```bash
   cd api
   ```
2. Instala las dependencias:
   ```bash
   npm install
   ```
3. Inicia el servidor:
   ```bash
   node index.js
   ```
   El servidor se ejecutará en `http://localhost:3000`

### Panel de Administración Web
1. Navega a la carpeta del panel de administración:
   ```bash
   cd web/panel-admin
   ```
2. Instala las dependencias:
   ```bash
   npm install
   ```
3. Inicia el servidor de desarrollo:
   ```bash
   npm run dev
   ```
   La aplicación web estará disponible en `http://localhost:5173`

### Simuladores de Pantallas
Los simuladores están disponibles en las siguientes rutas:
- Simulador Pantalla 1: `http://localhost:3000/simulador.html`
- Simulador Pantalla 2: `http://localhost:3000/simulador2.html`

Para usar los simuladores:
1. Asegúrate de que el servidor backend esté en ejecución
2. Abre las URLs de los simuladores en el navegador
3. Los simuladores mostrarán el contenido programado para cada pantalla

## Estructura del Proyecto

- `api/`: Servidor backend (Node.js + Express)
  - `rutas/`: Endpoints de la API
  - `middleware/`: Middleware de autenticación
  - `database.sql`: Script de creación de la base de datos
- `web/panel-admin/`: Panel de administración (React)
  - `src/`: Código fuente
  - `public/`: Archivos estáticos
- `simuladores/`: Simuladores de pantallas
  - `simulador.html`: Simulador de la Pantalla 1
  - `simulador2.html`: Simulador de la Pantalla 2

## Características

- Gestión de usuarios (crear, editar, eliminar)
- Gestión de pantallas
- Programación de contenido
- Simuladores de pantallas
- Autenticación y autorización
- Interfaz responsive

