package com.example.raspi_screen_control_app.models;

public class LoginResponse {
    private String token;

    public String getToken() { return token; }
}
