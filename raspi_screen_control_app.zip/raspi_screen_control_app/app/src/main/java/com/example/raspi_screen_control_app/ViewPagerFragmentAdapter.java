package com.example.raspi_screen_control_app;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.viewpager2.adapter.FragmentStateAdapter;

public class ViewPagerFragmentAdapter extends FragmentStateAdapter {

    private String token;

    public ViewPagerFragmentAdapter(@NonNull FragmentActivity fragmentActivity, String token) {
        super(fragmentActivity);
        this.token = token;
    }

    @NonNull
    @Override
    public Fragment createFragment(int position) {
        switch (position) {
            case 0:
                return PantallasFragment.newInstance(token);
            case 1:
                return AssetsFragment.newInstance(token);
            case 2:
                return ProgramacionesFragment.newInstance(token);
            default:
                return PantallasFragment.newInstance(token);
        }
    }

    @Override
    public int getItemCount() {
        return 3; // Number of tabs (Pantallas, Assets, Programaciones)
    }

    // Método para refrescar un fragmento específico si es necesario
    public void refreshFragment(int position) {

        if (getFragment(position) instanceof PantallasFragment) {
            ((PantallasFragment) getFragment(position)).refreshPantallas();
        }
    }

    // Método para obtener una instancia del fragmento (para refrescar o acceder a sus métodos)
    public Fragment getFragment(int position) {
        return createFragment(position); // Recreamos el fragmento para asegurar que los datos estén actualizados
    }
} 