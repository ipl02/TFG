package com.example.raspi_screen_control_app.models;

import android.os.Build;

import com.google.gson.annotations.SerializedName;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonParseException;
import com.google.gson.annotations.JsonAdapter;
import java.lang.reflect.Type;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Asset {
    @SerializedName("id")
    private int id;

    @SerializedName("name")
    private String name;

    @SerializedName("uri")
    private String uri;

    @SerializedName("mimetype")
    private String mimetype;

    @SerializedName("duration")
    private Integer duration;

    @SerializedName("start_date")
    private String startDate;

    @SerializedName("end_date")
    private String endDate;

    @SerializedName("is_active")
    @JsonAdapter(BooleanTypeAdapter.class)
    private Boolean isActive;

    @SerializedName("is_enabled")
    @JsonAdapter(BooleanTypeAdapter.class)
    private Boolean isEnabled;

    @SerializedName("is_processing")
    @JsonAdapter(BooleanTypeAdapter.class)
    private Boolean isProcessing;

    @SerializedName("nocache")
    @JsonAdapter(BooleanTypeAdapter.class)
    private Boolean nocache;

    @SerializedName("skip_asset_check")
    @JsonAdapter(BooleanTypeAdapter.class)
    private Boolean skipAssetCheck;

    @SerializedName("play_order")
    private Integer playOrder;

    @SerializedName("asset_id")
    private Integer assetId;

    @SerializedName("usuario_id")
    private Integer usuarioId;

    @SerializedName("updated_at")
    private String updatedAt;

    // TypeAdapter personalizado para manejar campos booleanos
    public static class BooleanTypeAdapter implements JsonDeserializer<Boolean> {
        @Override
        public Boolean deserialize(JsonElement json, Type typeOfT, JsonDeserializationContext context) 
            throws JsonParseException {
            if (json.isJsonNull()) {
                return null;
            }
            if (json.isJsonPrimitive()) {
                if (json.getAsJsonPrimitive().isBoolean()) {
                    return json.getAsBoolean();
                }
                if (json.getAsJsonPrimitive().isNumber()) {
                    return json.getAsInt() == 1;
                }
            }
            return false;
        }
    }

    // Constructor por defecto que establece valores iniciales
    public Asset() {
        // Establecer end_date por defecto a 1 año desde ahora
        LocalDateTime oneYearFromNow = null;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            oneYearFromNow = LocalDateTime.now().plusYears(1);
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            this.endDate = oneYearFromNow.format(DateTimeFormatter.ISO_DATE_TIME);
        }
        this.isActive = true;
        this.isEnabled = true;
        this.isProcessing = false;
        this.nocache = false;
        this.skipAssetCheck = false;
        this.playOrder = 0;
    }

    // Getters y Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getUri() {
        return uri;
    }

    public void setUri(String uri) {
        this.uri = uri;
    }

    public String getMimetype() {
        return mimetype;
    }

    public void setMimetype(String mimetype) {
        this.mimetype = mimetype;
    }

    public Integer getDuration() {
        return duration;
    }

    public void setDuration(Integer duration) {
        this.duration = duration;
    }

    public String getStartDate() {
        return startDate;
    }

    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    public String getEndDate() {
        return endDate;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    public Boolean getIsActive() {
        return isActive;
    }

    public void setIsActive(Boolean isActive) {
        this.isActive = isActive;
    }

    public Boolean getIsEnabled() {
        return isEnabled;
    }

    public void setIsEnabled(Boolean isEnabled) {
        this.isEnabled = isEnabled;
    }

    public Boolean getIsProcessing() {
        return isProcessing;
    }

    public void setIsProcessing(Boolean isProcessing) {
        this.isProcessing = isProcessing;
    }

    public Boolean getNocache() {
        return nocache;
    }

    public void setNocache(Boolean nocache) {
        this.nocache = nocache;
    }

    public Boolean getSkipAssetCheck() {
        return skipAssetCheck;
    }

    public void setSkipAssetCheck(Boolean skipAssetCheck) {
        this.skipAssetCheck = skipAssetCheck;
    }

    public Integer getPlayOrder() {
        return playOrder;
    }

    public void setPlayOrder(Integer playOrder) {
        this.playOrder = playOrder;
    }

    public Integer getAssetId() {
        return assetId;
    }

    public void setAssetId(Integer assetId) {
        this.assetId = assetId;
    }

    public Integer getUsuarioId() {
        return usuarioId;
    }

    public void setUsuarioId(Integer usuarioId) {
        this.usuarioId = usuarioId;
    }

    public String getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(String updatedAt) {
        this.updatedAt = updatedAt;
    }

    @Override
    public String toString() {
        // para que el Spinner muestre el nombre
        return name;
    }
}
