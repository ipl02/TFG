package com.example.raspi_screen_control_app;

import android.view.*;
import android.widget.*;
import androidx.recyclerview.widget.RecyclerView;
import com.example.raspi_screen_control_app.models.Pantalla;
import java.util.List;

public class PantallaAdapter extends RecyclerView.Adapter<PantallaAdapter.VH> {
    List<Pantalla> list; OnItemClickListener listener;
    interface OnItemClickListener { void onEdit(Pantalla p); void onDelete(int id); }

    public PantallaAdapter(List<Pantalla> l, OnItemClickListener ls) {
        list = l; listener = ls;
    }
    @Override public VH onCreateViewHolder(ViewGroup p, int v) {
        return new VH(LayoutInflater.from(p.getContext()).inflate(R.layout.item_pantalla, p, false));
    }
    @Override public void onBindViewHolder(VH h, int pos) {
        Pantalla p = list.get(pos);
        h.tvNombre.setText(p.getNombre());
        h.tvIP.setText(p.getDireccion_IP());
        h.tvUbicacion.setText(p.getUbicacion());
        h.tvEstado.setText(p.getEstado());
        h.itemView.setOnClickListener(v -> listener.onEdit(p));
        h.itemView.setOnLongClickListener(v -> { listener.onDelete(p.getId()); return true; });
    }
    @Override public int getItemCount() { return list.size(); }

    static class VH extends RecyclerView.ViewHolder {
        TextView tvNombre, tvIP, tvUbicacion, tvEstado;
        VH(View v) {
            super(v);
            tvNombre = v.findViewById(R.id.tvNombre);
            tvIP = v.findViewById(R.id.tvIP);
            tvUbicacion = v.findViewById(R.id.tvUbicacion);
            tvEstado = v.findViewById(R.id.tvEstado);
        }
    }
}
