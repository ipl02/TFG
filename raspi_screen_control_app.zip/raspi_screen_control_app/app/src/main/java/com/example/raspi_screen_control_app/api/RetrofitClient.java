package com.example.raspi_screen_control_app.api;

import android.util.Log;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class RetrofitClient {
    private static Retrofit retrofit = null;
    // usa siempre la misma BASE_URL
    private static final String BASE_URL = "http://10.0.2.2:3000/api/";


    public static ApiService getApi(String token) {
        OkHttpClient.Builder httpBuilder = new OkHttpClient.Builder();

        // Agregar interceptor de logging
        HttpLoggingInterceptor logging = new HttpLoggingInterceptor();
        logging.setLevel(HttpLoggingInterceptor.Level.BODY);
        httpBuilder.addInterceptor(logging);

        // Agregar interceptor para headers comunes y token
        httpBuilder.addInterceptor(chain -> {
            Request original = chain.request();
            Request.Builder builder = original.newBuilder();

            // Headers comunes
            builder.header("Accept", "application/json")
                   .header("Content-Type", "application/json");

            // Agregar token si existe
            if (token != null && !token.isEmpty()) {
                String cleanToken = token.trim();
                String authHeader = "Bearer " + cleanToken;
                Log.d("RetrofitClient", "Configurando token: " + authHeader);
                builder.addHeader("authorization", authHeader);
            } else {
                Log.w("RetrofitClient", "No se proporcionó token");
            }

            // Construir la request final
            Request request = builder.method(original.method(), original.body()).build();
            
            // Log de la request
            Log.d("RetrofitClient", "Enviando request a: " + request.url());
            Log.d("RetrofitClient", "Método: " + request.method());
            Log.d("RetrofitClient", "Headers completos:");
            for (String name : request.headers().names()) {
                Log.d("RetrofitClient", name + ": " + request.header(name));
            }
            
            // Ejecutar la request
            okhttp3.Response response = chain.proceed(request);
            
            // Log de la respuesta
            Log.d("RetrofitClient", "Respuesta recibida - Código: " + response.code());
            Log.d("RetrofitClient", "Respuesta recibida - Mensaje: " + response.message());
            Log.d("RetrofitClient", "Respuesta recibida - Headers:");
            for (String name : response.headers().names()) {
                Log.d("RetrofitClient", name + ": " + response.header(name));
            }
            
            // Si hay un error 401, intentar leer el cuerpo de la respuesta
            if (response.code() == 401 && response.body() != null) {
                try {
                    String errorBody = response.body().string();
                    Log.e("RetrofitClient", "Error 401 - Cuerpo de respuesta: " + errorBody);
                } catch (Exception e) {
                    Log.e("RetrofitClient", "Error al leer cuerpo de respuesta 401", e);
                }
            }
            
            return response;
        });

        // Crear una nueva instancia de Retrofit cada vez para evitar problemas de caché
        retrofit = new Retrofit.Builder()
                .baseUrl(BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .client(httpBuilder.build())
                .build();

        return retrofit.create(ApiService.class);
    }
}
