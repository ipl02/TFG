package com.example.raspi_screen_control_app;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.example.raspi_screen_control_app.api.ApiService;
import com.example.raspi_screen_control_app.api.RetrofitClient;
import com.example.raspi_screen_control_app.models.Pantalla;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class PantallasFragment extends Fragment {

    private RecyclerView rv;
    private PantallaAdapter pantallaAdapter;
    private List<Pantalla> pantallas = new ArrayList<>();
    private String token;

    public PantallasFragment() {
        // Required empty public constructor
    }

    public static PantallasFragment newInstance(String token) {
        PantallasFragment fragment = new PantallasFragment();
        Bundle args = new Bundle();
        args.putString("token", token);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            token = getArguments().getString("token");
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_pantallas, container, false);

        rv = view.findViewById(R.id.rvPantallasFragment);
        pantallaAdapter = new PantallaAdapter(pantallas, new PantallaAdapter.OnItemClickListener() {
            @Override public void onEdit(Pantalla p) { 
                if (getActivity() instanceof MainActivity) {
                    ((MainActivity) getActivity()).showPantallaDialog(p);
                }
            }
            @Override public void onDelete(int id) {
                if (getActivity() instanceof MainActivity) {
                    ((MainActivity) getActivity()).deletePantalla(id);
                }
            }
        });
        rv.setLayoutManager(new LinearLayoutManager(getContext()));
        rv.setAdapter(pantallaAdapter);

        if (token != null && !token.isEmpty()) {
            loadPantallas();
        } else {
            if (getActivity() != null) {
                Toast.makeText(getActivity(), "Error: Token de sesión no disponible", Toast.LENGTH_LONG).show();
            }
        }

        return view;
    }

    public void refreshPantallas() {
        loadPantallas();
    }

    private void loadPantallas() {
        if (getContext() == null || !isAdded()) {
            return;
        }

        ApiService api = RetrofitClient.getApi(token);
        if (api == null) {
            if (getContext() != null) {
                Toast.makeText(getContext(), "Error: API no inicializada", Toast.LENGTH_LONG).show();
            }
            return;
        }

        api.getPantallas().enqueue(new Callback<List<Pantalla>>() {
            @Override
            public void onResponse(Call<List<Pantalla>> call, Response<List<Pantalla>> res) {
                if (!isAdded() || getContext() == null) {
                    return;
                }

                if (res.isSuccessful() && res.body() != null) {
                    pantallas.clear();
                    pantallas.addAll(res.body());
                    pantallaAdapter.notifyDataSetChanged();
                } else {
                    Toast.makeText(getContext(), "Error al cargar pantallas", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<List<Pantalla>> call, Throwable t) {
                if (getContext() != null && isAdded()) {
                    Toast.makeText(getContext(), "Error de conexión: " + t.getMessage(), Toast.LENGTH_LONG).show();
                }
            }
        });
    }
} 