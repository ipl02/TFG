package com.example.raspi_screen_control_app;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.raspi_screen_control_app.models.Asset;

import java.util.List;

public class AssetAdapter extends RecyclerView.Adapter<AssetAdapter.ViewHolder> {

    private List<Asset> assets;

    public AssetAdapter(List<Asset> assets) {
        this.assets = assets;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_asset, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Asset asset = assets.get(position);
        holder.tvAssetName.setText(asset.getName());
        holder.tvAssetUri.setText(asset.getUri());
    }

    @Override
    public int getItemCount() {
        return assets.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvAssetName;
        TextView tvAssetUri;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvAssetName = itemView.findViewById(R.id.tvAssetName);
            tvAssetUri = itemView.findViewById(R.id.tvAssetUri);
        }
    }
} 