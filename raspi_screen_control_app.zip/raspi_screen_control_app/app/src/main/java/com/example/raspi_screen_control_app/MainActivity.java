package com.example.raspi_screen_control_app;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.InputType;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import com.example.raspi_screen_control_app.api.ApiService;
import com.example.raspi_screen_control_app.api.RetrofitClient;
import com.example.raspi_screen_control_app.models.Asset;
import com.example.raspi_screen_control_app.models.Pantalla;
import com.example.raspi_screen_control_app.models.Programacion;
import com.google.android.material.appbar.MaterialToolbar;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import androidx.drawerlayout.widget.DrawerLayout;
import com.google.android.material.navigation.NavigationView;
import com.google.android.material.tabs.TabLayout;
import androidx.viewpager2.widget.ViewPager2;
import com.google.android.material.tabs.TabLayoutMediator;
import android.util.Log;
import android.content.SharedPreferences;
import java.io.IOException;
import android.util.SparseBooleanArray;
import java.util.ArrayList;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import java.util.Calendar;

public class MainActivity extends AppCompatActivity {
    private DrawerLayout drawerLayout;
    private NavigationView navigationView;
    private String token;
    private TabLayout tabLayout;
    private ViewPager2 viewPager;
    private ViewPagerFragmentAdapter viewPagerAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        drawerLayout   = findViewById(R.id.drawer_layout);
        navigationView = findViewById(R.id.nav_view);

        MaterialToolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        toolbar.setNavigationOnClickListener(v -> drawerLayout.open());

        // Obtener token
        String tokenFromIntent = getIntent().getStringExtra("token");
        token = (tokenFromIntent != null ? tokenFromIntent.trim() :
                getSharedPreferences("prefs", MODE_PRIVATE).getString("token", null));

        if (TextUtils.isEmpty(token)) {
            Toast.makeText(this, "No hay token de sesión", Toast.LENGTH_LONG).show();
            startActivity(new Intent(this, LoginActivity.class));
            finish();
            return;
        }

        // Configurar ViewPager2 + TabLayout
        tabLayout = findViewById(R.id.tab_layout);
        viewPager = findViewById(R.id.view_pager);
        viewPagerAdapter = new ViewPagerFragmentAdapter(this, token);
        viewPager.setAdapter(viewPagerAdapter);
        new TabLayoutMediator(tabLayout, viewPager, (tab, pos) -> {
            switch (pos) {
                case 0: tab.setText("Pantallas");     break;
                case 1: tab.setText("Assets");        break;
                case 2: tab.setText("Programaciones");break;
            }
        }).attach();

        // Navigation Drawer actions
        navigationView.setNavigationItemSelectedListener(item -> {
            int id = item.getItemId();
            if (id == R.id.nav_menu_add_asset) {
                showAssetDialog();
            } else if (id == R.id.nav_menu_schedule) {
                showScheduleDialog();
            } else if (id == R.id.nav_menu_add_pantalla) {
                showPantallaDialog(null);
            }
            drawerLayout.closeDrawers();
            return true;
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.action_logout) {
            getSharedPreferences("prefs", MODE_PRIVATE).edit().remove("token").apply();
            startActivity(new Intent(this, LoginActivity.class));
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void showAssetDialog() {
        SharedPreferences prefs = getSharedPreferences("prefs", MODE_PRIVATE);
        String token = prefs.getString("token", "");
        
        if (token.isEmpty()) {
            Toast.makeText(this, "Error: Token no disponible", Toast.LENGTH_SHORT).show();
            startActivity(new Intent(this, LoginActivity.class));
            finish();
            return;
        }

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        View view = getLayoutInflater().inflate(R.layout.dialog_asset, null);
        
        EditText etName = view.findViewById(R.id.etAssetName);
        EditText etUri = view.findViewById(R.id.etAssetUri);
        EditText etMimetype = view.findViewById(R.id.etAssetMimetype);
        EditText etDuration = view.findViewById(R.id.etAssetDuration);

        builder.setView(view)
               .setTitle("Nuevo Asset")
               .setPositiveButton("Guardar", null)
               .setNegativeButton("Cancelar", (dialog, which) -> dialog.dismiss());

        AlertDialog dialog = builder.create();
        dialog.show();

        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            String name = etName.getText().toString().trim();
            String uri = etUri.getText().toString().trim();
            String mimetype = etMimetype.getText().toString().trim();
            String durationStr = etDuration.getText().toString().trim();

            if (name.isEmpty() || uri.isEmpty() || mimetype.isEmpty()) {
                Toast.makeText(this, "Por favor complete todos los campos requeridos", Toast.LENGTH_SHORT).show();
                return;
            }

            if (!isValidMimetype(mimetype)) {
                Toast.makeText(this, "Tipo MIME inválido. Ejemplos válidos: video/mp4, image/jpeg", Toast.LENGTH_SHORT).show();
                return;
            }

            Asset asset = new Asset();
            asset.setName(name);
            asset.setUri(uri);
            asset.setMimetype(mimetype);
            
            if (!durationStr.isEmpty()) {
                try {
                    int duration = Integer.parseInt(durationStr);
                    if (duration > 0) {
                        asset.setDuration(duration);
                    }
                } catch (NumberFormatException e) {
                    Log.e("MainActivity", "Error al parsear duración: " + e.getMessage());
                }
            }

            final ApiService api = RetrofitClient.getApi(token);

            api.createAsset(asset).enqueue(new Callback<Asset>() {
                @Override
                public void onResponse(Call<Asset> call, Response<Asset> response) {
                    if (response.isSuccessful()) {
                        if (viewPager.getAdapter() instanceof ViewPagerFragmentAdapter) {
                            ((ViewPagerFragmentAdapter)viewPager.getAdapter()).refreshFragment(1);
                        }
                        dialog.dismiss();
                    } else {
                        String errorMessage = "Error al crear el asset";
                        try {
                            if (response.errorBody() != null) {
                                String errorBody = response.errorBody().string();
                                if (response.code() == 401) {
                                    handleTokenError();
                                    return;
                                } else {
                                    errorMessage = "Error: " + errorBody;
                                }
                            }
                        } catch (IOException e) {
                            Log.e("MainActivity", "Error al leer el cuerpo del error: " + e.getMessage());
                        }
                        Toast.makeText(MainActivity.this, errorMessage, Toast.LENGTH_LONG).show();
                    }
                }

                @Override
                public void onFailure(Call<Asset> call, Throwable t) {
                    if (isFinishing() || isDestroyed()) return;
                    Toast.makeText(MainActivity.this, 
                        "Error de conexión: " + t.getMessage(), 
                        Toast.LENGTH_LONG).show();
                }
            });
        });
    }

    private boolean isValidMimetype(String mimetype) {
        return mimetype.matches("^(image|video|application)/[a-zA-Z0-9.+-]+$");
    }

    private void showScheduleDialog() {
        ApiService api = RetrofitClient.getApi(token);
        AlertDialog.Builder b = new AlertDialog.Builder(this);
        View v = LayoutInflater.from(this).inflate(R.layout.dialog_schedule, null);

        ListView lvPantallas = v.findViewById(R.id.lvPantallas);
        Spinner spAsset = v.findViewById(R.id.spAsset);
        EditText etStart = v.findViewById(R.id.etStart);
        EditText etEnd = v.findViewById(R.id.etEnd);
        for (EditText et : new EditText[]{etStart, etEnd}) {
            et.setInputType(InputType.TYPE_NULL);
            et.setOnClickListener(view -> {
                final Calendar c = Calendar.getInstance();
                // 1) Mostrar DatePicker
                new DatePickerDialog(MainActivity.this,
                        (dp, y, m, d) -> {
                            c.set(y, m, d);
                            // 2) Tras fecha, mostrar TimePicker
                            new TimePickerDialog(MainActivity.this,
                                    (tp, h, min) -> {
                                        c.set(Calendar.HOUR_OF_DAY, h);
                                        c.set(Calendar.MINUTE, min);
                                        // 3) Formatear y poner en el EditText
                                        String txt = new SimpleDateFormat(
                                                "yyyy-MM-dd HH:mm:ss", Locale.getDefault()
                                        ).format(c.getTime());
                                        et.setText(txt);
                                    },
                                    c.get(Calendar.HOUR_OF_DAY),
                                    c.get(Calendar.MINUTE),
                                    true
                            ).show();
                        },
                        c.get(Calendar.YEAR),
                        c.get(Calendar.MONTH),
                        c.get(Calendar.DAY_OF_MONTH)
                ).show();
            });
        }
        EditText etOrder = v.findViewById(R.id.etOrder);
        v.findViewById(R.id.etCreatedBy).setVisibility(View.GONE);

        etStart.setOnClickListener(view -> {
            Calendar c = Calendar.getInstance();
            DatePickerDialog datePickerDialog = new DatePickerDialog(this,
                    (view1, year, month, dayOfMonth) -> {
                        String date = String.format("%04d-%02d-%02d 00:00:00", year, month + 1, dayOfMonth);
                        etStart.setText(date);
                    },
                    c.get(Calendar.YEAR),
                    c.get(Calendar.MONTH),
                    c.get(Calendar.DAY_OF_MONTH));
            datePickerDialog.show();
        });

        etEnd.setOnClickListener(view -> {
            Calendar c = Calendar.getInstance();
            DatePickerDialog datePickerDialog = new DatePickerDialog(this,
                    (view1, year, month, dayOfMonth) -> {
                        String date = String.format("%04d-%02d-%02d 23:59:59", year, month + 1, dayOfMonth);
                        etEnd.setText(date);
                    },
                    c.get(Calendar.YEAR),
                    c.get(Calendar.MONTH),
                    c.get(Calendar.DAY_OF_MONTH));
            datePickerDialog.show();
        });

        final AlertDialog dialog = b.setView(v)
                .setTitle("Programar Asset")
                .setPositiveButton("Guardar", null)
                .setNegativeButton("Cancelar", null)
                .create();

        api.getPantallas().enqueue(new Callback<List<Pantalla>>() {
            @Override public void onResponse(Call<List<Pantalla>> c, Response<List<Pantalla>> r) {
                if (r.isSuccessful() && r.body() != null) {
                    ArrayAdapter<Pantalla> adapter = new ArrayAdapter<Pantalla>(
                            MainActivity.this, 
                            android.R.layout.simple_list_item_multiple_choice, 
                            r.body()) {
                        @Override
                        public View getView(int position, View convertView, ViewGroup parent) {
                            View view = super.getView(position, convertView, parent);
                            TextView text = (TextView) view.findViewById(android.R.id.text1);
                            text.setText(getItem(position).getNombre());
                            return view;
                        }
                    };
                    lvPantallas.setAdapter(adapter);
                    lvPantallas.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE);
                }
            }
            @Override public void onFailure(Call<List<Pantalla>> c, Throwable t) { }
        });

        api.getAssets().enqueue(new Callback<List<Asset>>() {
            @Override public void onResponse(Call<List<Asset>> c, Response<List<Asset>> r) {
                if (r.isSuccessful()) {
                    ArrayAdapter<Asset> a = new ArrayAdapter<Asset>(
                            MainActivity.this, android.R.layout.simple_spinner_item, r.body()) {
                        @Override
                        public View getView(int position, View convertView, ViewGroup parent) {
                            View view = super.getView(position, convertView, parent);
                            TextView text = (TextView) view.findViewById(android.R.id.text1);
                            text.setText(getItem(position).getName());
                            return view;
                        }

                        @Override
                        public View getDropDownView(int position, View convertView, ViewGroup parent) {
                            View view = super.getDropDownView(position, convertView, parent);
                            TextView text = (TextView) view.findViewById(android.R.id.text1);
                            text.setText(getItem(position).getName());
                            return view;
                        }
                    };
                    a.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                    spAsset.setAdapter(a);
                }
            }
            @Override public void onFailure(Call<List<Asset>> c, Throwable t) { }
        });

        dialog.setOnShowListener(di -> {
            Button btn = dialog.getButton(AlertDialog.BUTTON_POSITIVE);
            btn.setOnClickListener(view -> {
                SparseBooleanArray checked = lvPantallas.getCheckedItemPositions();
                List<Integer> selectedPantallaIds = new ArrayList<>();
                for (int i = 0; i < checked.size(); i++) {
                    if (checked.valueAt(i)) {
                        Pantalla pantalla = (Pantalla) lvPantallas.getItemAtPosition(checked.keyAt(i));
                        selectedPantallaIds.add(pantalla.getId());
                    }
                }

                if (selectedPantallaIds.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Seleccione al menos una pantalla", Toast.LENGTH_SHORT).show();
                    return;
                }

                Asset selAst = (Asset) spAsset.getSelectedItem();
                if (selAst == null) {
                    Toast.makeText(MainActivity.this, "Seleccione un asset", Toast.LENGTH_SHORT).show();
                    return;
                }

                String startStr = etStart.getText().toString().trim();
                String endStr = etEnd.getText().toString().trim();
                
                if (startStr.isEmpty() || endStr.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Las fechas son obligatorias", Toast.LENGTH_SHORT).show();
                    return;
                }

                try {
                    SimpleDateFormat fmt = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
                    Date d1 = fmt.parse(startStr);
                    Date d2 = fmt.parse(endStr);
                    
                    if (d1.after(d2)) {
                        Toast.makeText(MainActivity.this, "La fecha de inicio debe ser anterior a la fecha de fin", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    Programacion prog = new Programacion();
                    prog.setPantalla_ids(selectedPantallaIds);
                    prog.setAsset_id(selAst.getId());
                    prog.setCreated_by("admin");
                    prog.setStart_date(startStr);
                    prog.setEnd_date(endStr);
                    
                    String orderStr = etOrder.getText().toString().trim();
                    if (!orderStr.isEmpty()) {
                        prog.setPlay_order(Integer.parseInt(orderStr));
                    }

                    api.createProgramacion(prog).enqueue(new Callback<Programacion>() {
                        @Override public void onResponse(Call<Programacion> c, Response<Programacion> r) {
                            if (r.isSuccessful()) {
                                runOnUiThread(() -> {
                                    Toast.makeText(MainActivity.this,
                                            "Programación creada", 
                                            Toast.LENGTH_SHORT).show();
                                    ((ViewPagerFragmentAdapter)viewPager.getAdapter())
                                            .refreshFragment(2);
                                    dialog.dismiss();
                                });
                            } else {
                                String errorMsg = "Error del servidor: " + r.code();
                                if (r.code() == 401) {
                                    handleTokenError();
                                    return;
                                }
                                String finalErrorMsg = errorMsg;
                                runOnUiThread(() -> Toast.makeText(MainActivity.this, finalErrorMsg, Toast.LENGTH_LONG).show());
                            }
                        }
                        @Override public void onFailure(Call<Programacion> c, Throwable t) {
                            runOnUiThread(() -> Toast.makeText(MainActivity.this,
                                    "Error de conexión: " + t.getMessage(), 
                                    Toast.LENGTH_LONG).show());
                        }
                    });
                } catch (ParseException e) {
                    Toast.makeText(MainActivity.this, "Formato de fecha inválido", Toast.LENGTH_SHORT).show();
                } catch (NumberFormatException e) {
                    Toast.makeText(MainActivity.this, "El orden de reproducción debe ser un número", Toast.LENGTH_SHORT).show();
                }
            });
        });
        dialog.show();
    }

    // --- Diálogo para crear/editar pantalla ---
    public void showPantallaDialog(Pantalla p) {
        if (TextUtils.isEmpty(token)) {
            Toast.makeText(this, "Error: Token de sesión no disponible", Toast.LENGTH_LONG).show();
            startActivity(new Intent(this, LoginActivity.class));
            finish();
            return;
        }

        final ApiService api = RetrofitClient.getApi(token);
        boolean isEdit = (p != null);
        AlertDialog.Builder b = new AlertDialog.Builder(this);
        View v = LayoutInflater.from(this).inflate(R.layout.dialog_pantalla, null);

        EditText etNombre = v.findViewById(R.id.etNombre);
        EditText etIP = v.findViewById(R.id.etIP);
        EditText etUbicacion = v.findViewById(R.id.etUbicacion);
        Spinner spEstado = v.findViewById(R.id.spEstado);

        if (isEdit) {
            etNombre.setText(p.getNombre());
            etIP.setText(p.getDireccion_IP());
            etUbicacion.setText(p.getUbicacion());
            spEstado.setSelection(p.getEstado().equals("activa") ? 0 : 1);
        }

        AlertDialog dialog = b.setView(v)
                .setTitle(isEdit ? "Editar Pantalla" : "Añadir Pantalla")
                .setPositiveButton("Guardar", null)
                .setNegativeButton("Cancelar", null)
                .create();

        dialog.setOnShowListener(dialogInterface -> {
            Button button = dialog.getButton(AlertDialog.BUTTON_POSITIVE);
            button.setOnClickListener(view -> {
                String nombre = etNombre.getText().toString().trim();
                String ip = etIP.getText().toString().trim();
                String ubicacion = etUbicacion.getText().toString().trim();

                if (nombre.isEmpty()) {
                    etNombre.setError("El nombre es obligatorio");
                    return;
                }

                if (ip.isEmpty()) {
                    etIP.setError("La IP es obligatoria");
                    return;
                }

                if (!ip.matches("^[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}$")) {
                    etIP.setError("Formato de IP inválido");
                    return;
                }

                if (ubicacion.isEmpty()) {
                    etUbicacion.setError("La ubicación es obligatoria");
                    return;
                }

                if (TextUtils.isEmpty(token)) {
                    Toast.makeText(MainActivity.this, "Error: Token de sesión no disponible", Toast.LENGTH_LONG).show();
                    startActivity(new Intent(MainActivity.this, LoginActivity.class));
                    finish();
                    return;
                }

                final ApiService currentApi = RetrofitClient.getApi(token);

                Pantalla np = isEdit ? p : new Pantalla();
                np.setNombre(nombre);
                np.setDireccion_IP(ip);
                np.setUbicacion(ubicacion);
                np.setEstado(spEstado.getSelectedItem().toString());

                if (isEdit) {
                    currentApi.updatePantalla(np.getId(), np).enqueue(new Callback<Void>() {
                        @Override
                        public void onResponse(Call<Void> c, Response<Void> r) {
                            if (!isFinishing() && !isDestroyed()) {
                                if (r.isSuccessful()) {
                                    if (viewPager.getAdapter() instanceof ViewPagerFragmentAdapter) {
                                        ((ViewPagerFragmentAdapter) viewPager.getAdapter()).refreshFragment(0);
                                    }
                                    dialog.dismiss();
                                } else {
                                    String errorMsg = "Error del servidor: " + r.code();
                                    if (r.code() == 401) {
                                        handleTokenError();
                                        return;
                                    }
                                    Toast.makeText(MainActivity.this, errorMsg, Toast.LENGTH_LONG).show();
                                }
                            }
                        }
                        @Override
                        public void onFailure(Call<Void> c, Throwable t) {
                            if (!isFinishing() && !isDestroyed()) {
                                Toast.makeText(MainActivity.this,
                                    "Error de conexión: " + t.getMessage(),
                                    Toast.LENGTH_LONG).show();
                            }
                        }
                    });
                } else {
                    currentApi.createPantalla(np).enqueue(new Callback<Pantalla>() {
                        @Override
                        public void onResponse(Call<Pantalla> c, Response<Pantalla> r) {
                            if (!isFinishing() && !isDestroyed()) {
                                if (r.isSuccessful()) {
                                    if (viewPager.getAdapter() instanceof ViewPagerFragmentAdapter) {
                                        ((ViewPagerFragmentAdapter) viewPager.getAdapter()).refreshFragment(0);
                                    }
                                    dialog.dismiss();
                                } else {
                                    String errorMsg = "Error del servidor: " + r.code();
                                    if (r.code() == 401) {
                                        handleTokenError();
                                        return;
                                    }
                                    Toast.makeText(MainActivity.this, errorMsg, Toast.LENGTH_LONG).show();
                                }
                            }
                        }
                        @Override
                        public void onFailure(Call<Pantalla> c, Throwable t) {
                            if (!isFinishing() && !isDestroyed()) {
                                Toast.makeText(MainActivity.this,
                                    "Error de conexión: " + t.getMessage(),
                                    Toast.LENGTH_LONG).show();
                            }
                        }
                    });
                }
            });
        });

        dialog.show();
    }

    public void deletePantalla(int id) {
        ApiService api = RetrofitClient.getApi(token);
        api.deletePantalla(id).enqueue(new Callback<Void>() {
            @Override
            public void onResponse(Call<Void> c, Response<Void> r) {
                // Notificar al fragmento de pantallas para refrescar
                if (viewPager.getAdapter() instanceof ViewPagerFragmentAdapter) {
                    ((ViewPagerFragmentAdapter) viewPager.getAdapter()).refreshFragment(0);
                }
            }
            @Override
            public void onFailure(Call<Void> c, Throwable t) {
                Toast.makeText(MainActivity.this,
                        "Error: " + t.getMessage(),
                        Toast.LENGTH_LONG).show();
            }
        });
    }

    private void handleTokenError() {
        getSharedPreferences("prefs", MODE_PRIVATE)
            .edit()
            .remove("token")
            .apply();
        startActivity(new Intent(MainActivity.this, LoginActivity.class));
        finish();
    }
}
