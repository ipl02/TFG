package com.example.raspi_screen_control_app.api;

import com.example.raspi_screen_control_app.models.*;
import java.util.List;
import retrofit2.Call;
import retrofit2.http.*;

public interface ApiService {
    @POST("auth/login")
    Call<LoginResponse> login(@Body LoginRequest body);

    @GET("pantallas")
    Call<List<Pantalla>> getPantallas();

    @POST("pantallas")
    Call<Pantalla> createPantalla(@Body Pantalla p);

    @PUT("pantallas/{id}")
    Call<Void> updatePantalla(@Path("id") int id, @Body Pantalla p);

    @DELETE("pantallas/{id}")
    Call<Void> deletePantalla(@Path("id") int id);

    @GET("assets") Call<List<Asset>> getAssets();
    @POST("assets") Call<Asset> createAsset(@Body Asset a);

    @GET("programacion") Call<List<Programacion>> getProgramaciones();
    @POST("programacion") Call<Programacion> createProgramacion(@Body Programacion p);
}