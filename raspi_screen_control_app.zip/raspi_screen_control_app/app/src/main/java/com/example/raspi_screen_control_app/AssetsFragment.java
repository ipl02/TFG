package com.example.raspi_screen_control_app;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.example.raspi_screen_control_app.api.ApiService;
import com.example.raspi_screen_control_app.api.RetrofitClient;
import com.example.raspi_screen_control_app.models.Asset;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class AssetsFragment extends Fragment {

    private RecyclerView rv;
    private AssetAdapter assetAdapter;
    private List<Asset> assets = new ArrayList<>();
    private String token;

    public AssetsFragment() {
    }

    public static AssetsFragment newInstance(String token) {
        AssetsFragment fragment = new AssetsFragment();
        Bundle args = new Bundle();
        args.putString("token", token);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            token = getArguments().getString("token");
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_assets, container, false);

        rv = view.findViewById(R.id.rvAssetsFragment);
        assetAdapter = new AssetAdapter(assets);
        rv.setLayoutManager(new LinearLayoutManager(getContext()));
        rv.setAdapter(assetAdapter);

        if (token != null && !token.isEmpty()) {
            loadAssets();
        } else {
            Log.e("AssetsFragment", "Error: Token nulo o vacío en AssetsFragment");
            if (getActivity() != null) {
                Toast.makeText(getActivity(), "Error: Token de sesión no disponible", Toast.LENGTH_LONG).show();
            }
        }

        return view;
    }

    public void refreshAssets() {
        if (token != null && !token.isEmpty()) {
            loadAssets();
        }
    }

    void loadAssets() {
        ApiService api = RetrofitClient.getApi(token);
        if (api == null) {
            Toast.makeText(getContext(), "Error: API no inicializada", Toast.LENGTH_LONG).show();
            return;
        }

        Log.d("AssetsFragment", "Intentando cargar assets con token: " + token);
        api.getAssets().enqueue(new Callback<List<Asset>>() {
            @Override
            public void onResponse(Call<List<Asset>> call, Response<List<Asset>> res) {
                Log.d("AssetsFragment", "Respuesta del servidor - Código: " + res.code());
                Log.d("AssetsFragment", "Respuesta del servidor - Mensaje: " + res.message());
                if (res.errorBody() != null) {
                    try {
                        Log.e("AssetsFragment", "Error body: " + res.errorBody().string());
                    } catch (Exception e) {
                        Log.e("AssetsFragment", "Error al leer error body", e);
                    }
                }

                if (res.isSuccessful() && res.body() != null) {
                    assets.clear();
                    assets.addAll(res.body());
                    assetAdapter.notifyDataSetChanged();
                    Log.d("AssetsFragment", "Assets cargados exitosamente: " + res.body().size());
                } else {
                    String errorMsg = "Error del servidor: " + res.code();
                    if (res.code() == 401) {
                        errorMsg += " - Token inválido o expirado";
                        Log.e("AssetsFragment", errorMsg);
                        if (getActivity() != null) {
                            getActivity().getSharedPreferences("prefs", Context.MODE_PRIVATE)
                                .edit()
                                .remove("token")
                                .apply();
                            startActivity(new Intent(getActivity(), LoginActivity.class));
                            getActivity().finish();
                        }
                    }
                    Toast.makeText(getContext(), errorMsg, Toast.LENGTH_LONG).show();
                }
            }

            @Override
            public void onFailure(Call<List<Asset>> call, Throwable t) {
                Log.e("AssetsFragment", "Error de conexión", t);
                Toast.makeText(getContext(),
                    "Error de conexión: " + t.getMessage(),
                    Toast.LENGTH_LONG).show();
            }
        });
    }
} 