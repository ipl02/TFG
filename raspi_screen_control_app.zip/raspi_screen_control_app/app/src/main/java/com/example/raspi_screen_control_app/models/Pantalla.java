package com.example.raspi_screen_control_app.models;

public class Pantalla {
    private int id;
    private String nombre;
    private String direccion_IP;
    private String ubicacion;
    private String estado;

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }
    public String getDireccion_IP() { return direccion_IP; }
    public void setDireccion_IP(String direccion_IP) { this.direccion_IP = direccion_IP; }
    public String getUbicacion() { return ubicacion; }
    public void setUbicacion(String ubicacion) { this.ubicacion = ubicacion; }
    public String getEstado() { return estado; }
    public void setEstado(String estado) { this.estado = estado; }
}
