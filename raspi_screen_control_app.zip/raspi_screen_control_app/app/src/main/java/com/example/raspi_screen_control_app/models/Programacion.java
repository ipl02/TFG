package com.example.raspi_screen_control_app.models;
import com.google.gson.annotations.SerializedName;
import java.util.List;

public class Programacion {
    @SerializedName("id")
    private int id;

    @SerializedName("pantalla_ids")
    private List<Integer> pantalla_ids;

    @SerializedName("asset_id")
    private int asset_id;

    @SerializedName("is_enabled")
    private int is_enabled = 1;

    @SerializedName("play_order")
    private int play_order = 1;

    @SerializedName("start_date")
    private String start_date;

    @SerializedName("end_date")
    private String end_date;

    @SerializedName("created_by")
    private String created_by;

    @SerializedName("estado")
    private String estado = "activo";


    public Programacion() {}


    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    
    public List<Integer> getPantalla_ids() { return pantalla_ids; }
    public void setPantalla_ids(List<Integer> pantalla_ids) { this.pantalla_ids = pantalla_ids; }
    
    public int getAsset_id() { return asset_id; }
    public void setAsset_id(int asset_id) { this.asset_id = asset_id; }
    
    public int getIs_enabled() { return is_enabled; }
    public void setIs_enabled(int is_enabled) { this.is_enabled = is_enabled; }
    
    public int getPlay_order() { return play_order; }
    public void setPlay_order(int play_order) { this.play_order = play_order; }
    
    public String getStart_date() { return start_date; }
    public void setStart_date(String start_date) { this.start_date = start_date; }
    
    public String getEnd_date() { return end_date; }
    public void setEnd_date(String end_date) { this.end_date = end_date; }
    
    public String getCreated_by() { return created_by; }
    public void setCreated_by(String created_by) { this.created_by = created_by; }
    
    public String getEstado() { return estado; }
    public void setEstado(String estado) { this.estado = estado; }
}
