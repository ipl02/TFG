package com.example.raspi_screen_control_app;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.example.raspi_screen_control_app.api.ApiService;
import com.example.raspi_screen_control_app.api.RetrofitClient;
import com.example.raspi_screen_control_app.models.Asset;
import com.example.raspi_screen_control_app.models.Pantalla;
import com.example.raspi_screen_control_app.models.Programacion;

import java.util.ArrayList;
import java.util.List;
import java.util.HashMap;
import java.util.Map;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ProgramacionesFragment extends Fragment {

    private RecyclerView rv;
    private ProgramacionAdapter programacionAdapter;
    private List<Programacion> programaciones = new ArrayList<>();
    private Map<Integer, String> pantallaMap = new HashMap<>();
    private Map<Integer, String> assetsMap = new HashMap<>();
    private String token;

    public ProgramacionesFragment() {
    }

    public static ProgramacionesFragment newInstance(String token) {
        ProgramacionesFragment fragment = new ProgramacionesFragment();
        Bundle args = new Bundle();
        args.putString("token", token);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            token = getArguments().getString("token");
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_programaciones, container, false);

        rv = view.findViewById(R.id.rvProgramacionesFragment);
        programacionAdapter = new ProgramacionAdapter(programaciones, pantallaMap, assetsMap);
        rv.setLayoutManager(new LinearLayoutManager(getContext()));
        rv.setAdapter(programacionAdapter);

        if (token != null && !token.isEmpty()) {
            // Primero cargar pantallas y assets para tener sus nombres
            loadPantallas();
            loadAssets();
            // Luego cargar programaciones
            loadProgramaciones();
        } else {
            Log.e("ProgramacionesFragment", "Error: Token nulo o vacío en ProgramacionesFragment");
            if (getActivity() != null) {
                Toast.makeText(getActivity(), "Error: Token de sesión no disponible", Toast.LENGTH_LONG).show();

            }
        }

        return view;
    }

    private void loadPantallas() {
        ApiService api = RetrofitClient.getApi(token);
        api.getPantallas().enqueue(new Callback<List<Pantalla>>() {
            @Override
            public void onResponse(Call<List<Pantalla>> call, Response<List<Pantalla>> response) {
                if (response.isSuccessful() && response.body() != null) {
                    pantallaMap.clear();
                    for (Pantalla pantalla : response.body()) {
                        pantallaMap.put(pantalla.getId(), pantalla.getNombre());
                    }
                    programacionAdapter.notifyDataSetChanged();
                }
            }
            @Override
            public void onFailure(Call<List<Pantalla>> call, Throwable t) {
                Log.e("ProgramacionesFragment", "Error al cargar pantallas", t);
            }
        });
    }

    private void loadAssets() {
        ApiService api = RetrofitClient.getApi(token);
        api.getAssets().enqueue(new Callback<List<Asset>>() {
            @Override
            public void onResponse(Call<List<Asset>> call, Response<List<Asset>> response) {
                if (response.isSuccessful() && response.body() != null) {
                    assetsMap.clear();
                    for (Asset asset : response.body()) {
                        assetsMap.put(asset.getId(), asset.getName());
                    }
                    programacionAdapter.notifyDataSetChanged();
                }
            }
            @Override
            public void onFailure(Call<List<Asset>> call, Throwable t) {
                Log.e("ProgramacionesFragment", "Error al cargar assets", t);
            }
        });
    }

    private void loadProgramaciones() {
        ApiService api = RetrofitClient.getApi(token);
        if (api == null) {
            Toast.makeText(getContext(), "Error: API no inicializada", Toast.LENGTH_LONG).show();
            return;
        }

        Log.d("ProgramacionesFragment", "Intentando cargar programaciones con token: " + token);
        
        // Primero asegurarnos que tenemos las pantallas cargadas
        api.getPantallas().enqueue(new Callback<List<Pantalla>>() {
            @Override
            public void onResponse(Call<List<Pantalla>> call, Response<List<Pantalla>> response) {
                if (response.isSuccessful() && response.body() != null) {
                    pantallaMap.clear();
                    for (Pantalla pantalla : response.body()) {
                        pantallaMap.put(pantalla.getId(), pantalla.getNombre());
                    }
                    // Una vez que tenemos las pantallas, cargamos las programaciones
                    loadProgramacionesData();
                }
            }
            @Override
            public void onFailure(Call<List<Pantalla>> call, Throwable t) {
                Log.e("ProgramacionesFragment", "Error al cargar pantallas", t);
            }
        });
    }

    private void loadProgramacionesData() {
        ApiService api = RetrofitClient.getApi(token);
        api.getProgramaciones().enqueue(new Callback<List<Programacion>>() {
            @Override
            public void onResponse(Call<List<Programacion>> call, Response<List<Programacion>> res) {
                Log.d("ProgramacionesFragment", "Respuesta del servidor - Código: " + res.code());
                
                if (res.isSuccessful() && res.body() != null) {
                    programaciones.clear();
                    programaciones.addAll(res.body());
                    // Asegurarnos que el adaptador tiene el mapa de pantallas actualizado
                    programacionAdapter.setPantallaMap(pantallaMap);
                    programacionAdapter.notifyDataSetChanged();
                    Log.d("ProgramacionesFragment", "Programaciones cargadas exitosamente: " + res.body().size());
                } else {
                    String errorMsg = "Error del servidor: " + res.code();
                    if (res.code() == 401) {
                        errorMsg += " - Token inválido o expirado";
                        Log.e("ProgramacionesFragment", errorMsg);
                        if (getActivity() != null) {
                            getActivity().getSharedPreferences("prefs", Context.MODE_PRIVATE)
                                .edit()
                                .remove("token")
                                .apply();
                            startActivity(new Intent(getActivity(), LoginActivity.class));
                            getActivity().finish();
                        }
                    }
                    Toast.makeText(getContext(), errorMsg, Toast.LENGTH_LONG).show();
                }
            }

            @Override
            public void onFailure(Call<List<Programacion>> call, Throwable t) {
                Log.e("ProgramacionesFragment", "Error de conexión", t);
                Toast.makeText(getContext(),
                    "Error de conexión: " + t.getMessage(),
                    Toast.LENGTH_LONG).show();
            }
        });
    }
} 