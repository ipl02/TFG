package com.example.raspi_screen_control_app;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.raspi_screen_control_app.models.Programacion;

import java.util.Collections;
import java.util.List;
import java.util.Map;

public class ProgramacionAdapter extends RecyclerView.Adapter<ProgramacionAdapter.ViewHolder> {

    private Map<Integer,String> pantallaMap = Collections.emptyMap();
    private List<Programacion> programaciones;
    private Map<Integer, String> assetsMap;    // Map<id, nombre>

    public ProgramacionAdapter(List<Programacion> programaciones, 
                             Map<Integer, String> pantallaMap,
                             Map<Integer, String> assetsMap) {
        this.programaciones = programaciones;
        this.pantallaMap = pantallaMap;
        this.assetsMap = assetsMap;
    }

    public void setPantallaMap(Map<Integer,String> m) {
        this.pantallaMap = m;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_programacion, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Programacion programacion = programaciones.get(position);
        
        // Obtener la lista de IDs de pantallas
        List<Integer> pantallaIds = programacion.getPantalla_ids();
        StringBuilder pantallasNombres = new StringBuilder();
        
        if (pantallaIds != null && !pantallaIds.isEmpty()) {
            for (Integer pantallaId : pantallaIds) {
                String nombrePantalla = pantallaMap.getOrDefault(pantallaId, "Pantalla desconocida");
                if (pantallasNombres.length() > 0) {
                    pantallasNombres.append(", ");
                }
                pantallasNombres.append(nombrePantalla);
            }
        } else {
            pantallasNombres.append("Sin pantallas asignadas");
        }
        
        holder.tvPantallaId.setText("Pantallas: " + pantallasNombres.toString());
        
        // Obtener el nombre del asset
        String nombreAsset = assetsMap.getOrDefault(programacion.getAsset_id(), "Asset desconocido");
        holder.tvAssetId.setText("Asset: " + nombreAsset);
        
        holder.tvStartDate.setText("Inicio: " + programacion.getStart_date());
        holder.tvEndDate.setText("Fin: " + programacion.getEnd_date());
        holder.tvPlayOrder.setText("Orden: " + programacion.getPlay_order());
    }

    @Override
    public int getItemCount() {
        return programaciones.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvPantallaId;
        TextView tvAssetId;
        TextView tvPlayOrder;
        TextView tvStartDate;
        TextView tvEndDate;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvPantallaId = itemView.findViewById(R.id.tvPantallaId);
            tvAssetId = itemView.findViewById(R.id.tvAssetId);
            tvPlayOrder = itemView.findViewById(R.id.tvPlayOrder);
            tvStartDate = itemView.findViewById(R.id.tvStartDate);
            tvEndDate = itemView.findViewById(R.id.tvEndDate);
        }
    }
} 